# Workprint — mobile-first forced-labor risk demo

A shopper scans a garment-label QR (or types a brand / RN / country), and sees a colored verdict, three scores, what's unknown, and can compare two brands. Seed data only, no logins, no live data providers.

## 1. Screen-by-screen journey

- **Home `/`** — bold hero, big "Scan a label" button, "Enter brand or RN" field with optional country-of-origin and fiber, then a shelf of the 5 demo tees, each with a visible QR sticker.
- **Scan `/scan`** — live camera scanning in the browser. Fallbacks always visible: upload a photo of a QR, tap a demo tee, or type the code/brand/RN.
- **Result `/p/:slug`** — product hero, then in order: verdict chip + one plain sentence, the three scores, "What's missing" gap chips, the 5-tier ladder, known suppliers, evidence split into Verified finding vs Industry context, "How this was calculated", Compare button. Footer: demo disclaimer + "Request a correction" mailto.
- **Compare `/compare?a=&b=`** — a vs. card, not a table: verdicts side by side, the three scores, biggest known gaps, one plain sentence on what separates them.
- **Methodology `/methodology`** — the exact formulas, pulled from the same code the scores use, thresholds marked "draft, pending legal review".
- **Sources `/sources`** — source types used, what each one can and cannot prove, and the future-data-source list as copy only.

No other pages.

## 2. Data model (TypeScript)

- `Brand` — slug, qrPayload (WP-TEE-01…05), name, fake RN, countryOfOrigin, fiber, retailPrice, declaredUnitPrice, costFloorInputs, tiers, suppliers, evidence, gaps, flags (uflpaEntityMatch, cbpWroActive), precomputed scores.
- `TierNode` — tier 0–4, stage, actor, country, status Known | Estimated | Unknown, priceAnomaly / locationRisk / entityRisk inputs, nodeRisk, unknownTierRisk, sourceFootnote.
- `Evidence` — id, title, sourceName, sourceType (brand_claim | independent_audit | trade_record | news | certification | customs_shipment | official_list), date, independentOrBrand, findingOrContext, humanVerified, body.
- `Gap` — id, label, whyItMatters, severity.
- `ScoreBreakdown` — risk / confidence / transparency values plus the factor list that moved each number, so the UI can show "why".

## 3. The 5 seed brands (fictional, no real names or logos)

1. **Verdant Cotton Co.** — named Tier 1+2, recent independent audit, price above cost floor → Green.
2. **Bloomhaus** — marketing claims only, Tiers 2–4 unknown → Grey (confidence under 40), even though risk is mid.
3. **Northloop Basics** — named Vietnamese cut-and-sew, many CN/HK fabric suppliers, DOL-list lane context, two unverified leads that are stored but never shown → Amber.
4. **Statepoint Apparel** — one human-verified UFLPA/WRO-style match → Red by override.
5. **Everyday 3-Pack** — cheap tee, strong price anomaly, Tier 4 unknown with high inherited cotton-country risk → Amber/Red by formula, medium confidence.

Each carries cost-floor inputs, tiers 0–4 with statuses, evidence, gap chips, and precomputed scores that the recompute functions reproduce exactly.

## 4. Grey rule and UFLPA override in the UI

- **Grey rule** — confidence under 40 forces a grey chip and the line "We don't have enough to judge this one." The confidence meter shows the negative factors that pulled it down. Green is only possible when risk is low AND confidence is 40+.
- **UFLPA / WRO override** — red chip, risk pinned to 90, a banner above the scores naming the matched node, date, and source, and the transparency bar hard-capped at 20 with a visible "capped" marker. The override is shown as the reason on the "How this was calculated" panel.

## 5. Camera: stubbed vs implemented

- **Implemented** — real in-browser camera scanning of the QR code on a phone, plus decoding an uploaded QR image on desktop.
- **Stubbed** — no barcode/label OCR, no item-level SKU lookup. If the camera is blocked or unsupported, the page drops straight to the demo shelf and the type-in field with a plain explanation. Every scan resolves to a brand-level result, and the result page says so.

## 6. Build order

1. Design system (coral, sunflower, lime, cobalt, cream; bold rounded display type) + scoring formulas and recompute helpers.
2. Seed the 5 brands and verify each produces its target verdict color.
3. Shared pieces: VerdictChip, ScoreTriple, ConfidenceMeter, TransparencyBar, GapChips, TierLadder, EvidenceCard, ContextVsFindingBadge, CompareStrip.
4. Home, scan (camera + fallbacks), result page.
5. Compare, methodology, sources; disclaimer footer and final pass on a 390px phone so gaps and unknown tiers sit above the fold.

## Technical notes

- Formulas live in `src/config/scoring.ts` as the single source of truth; the methodology page renders from the same module so it cannot drift.
- Seed data in `src/data/brands.ts`; a test-style recompute check confirms precomputed scores match the formulas.
- Risk uses the worst tier, never the average. Unknown tiers use precomputed inherited country-mix risk, shown as a dashed ESTIMATED row.
- Unverified leads stay in the data with `humanVerified: false` and are filtered out of the shopper view.
- Product imagery: generated flat-lay tee photos, no logos, no depictions of workers or distress.
- No backend, no auth, no live API calls.
