# Workprint roadmap

## Phase 1 — foundation + shopper core loop (done)
- [x] Design tokens (coral, sunflower, lime, cobalt, cream) + mobile shell
- [x] src/config/scoring.ts — Risk, Confidence, Transparency, Grey rule, UFLPA/WRO override
- [x] src/data/brands.ts — 5 fictional cotton-tee brands, ladders, evidence, gaps
- [x] Recompute helpers matching the seed scores
- [x] Home: scan CTA, brand/RN entry, optional COO + fiber, demo shelf with QR stickers
- [x] Scanner: camera, permission-denied state, photo upload, type-code fallback
- [x] Result page /p/:slug
- [x] Methodology page rendering the real weights from scoring.ts
- [x] Verified verdicts: green / grey / amber / red / red

## Next
- [ ] Compare screen (/compare?a=&b=) — deferred by request
- [ ] Sources / about page
- No auth, no external APIs (out of scope for v1)
- [x] /compare page (picker from result page)
- [x] /sources page (seed source types, later seams, correction link)
