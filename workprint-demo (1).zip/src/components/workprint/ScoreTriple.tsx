import type { ScoreBreakdown } from "@/config/scoring";
import { verdictStyles } from "@/lib/verdict";
import { cn } from "@/lib/utils";

/** Risk = dial. Confidence = filled dots. Transparency = stacked bar. Three different shapes on purpose. */
export function ScoreTriple({ scores }: { scores: ScoreBreakdown }) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
      <RiskDial scores={scores} />
      <ConfidenceMeter value={scores.confidence} />
      <TransparencyBar value={scores.transparency} capped={scores.transparencyCapped} />
    </div>
  );
}

export function RiskDial({ scores }: { scores: ScoreBreakdown }) {
  const s = verdictStyles[scores.riskBand === "High" ? "red" : scores.riskBand === "Low" ? "green" : "amber"];
  // Half-circle gauge: length of the drawn arc = the score.
  const arc = Math.PI * 42; // radius 42
  return (
    <div className="rounded-3xl border-2 border-border bg-card p-4">
      <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Risk</p>
      <div className="relative mx-auto mt-3 w-[120px]">
        <svg viewBox="0 0 110 60" className="w-full">
          <path
            d="M 13 55 A 42 42 0 0 1 97 55"
            fill="none"
            strokeWidth="11"
            strokeLinecap="round"
            className="stroke-muted"
          />
          <path
            d="M 13 55 A 42 42 0 0 1 97 55"
            fill="none"
            strokeWidth="11"
            strokeLinecap="round"
            stroke="currentColor"
            className={cn("transition-all", s.text)}
            strokeDasharray={`${(scores.risk / 100) * arc} ${arc}`}
          />
        </svg>
        <span className="absolute inset-x-0 bottom-0 text-center text-3xl font-bold leading-none">
          {scores.risk}
        </span>
      </div>
      <p className={cn("mt-1 text-center text-sm font-bold", s.text)}>
        {scores.riskBand} risk
      </p>
      <p className="mt-1 text-center text-xs text-muted-foreground">
        Worst step in the chain, not the average
      </p>
    </div>
  );
}

export function ConfidenceMeter({ value }: { value: number }) {
  const filled = Math.round(value / 10);
  return (
    <div className="rounded-3xl border-2 border-border bg-card p-4">
      <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Confidence
      </p>
      <p className="mt-2 text-3xl font-bold leading-none">{value}</p>
      <div className="mt-3 flex gap-1">
        {Array.from({ length: 10 }).map((_, i) => (
          <span
            key={i}
            className={cn(
              "h-5 flex-1 rounded-full",
              i < filled ? "bg-cobalt" : "bg-muted",
            )}
          />
        ))}
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        {value < 40
          ? "We only partly trust this number."
          : value < 70
            ? "Decent, but there are holes."
            : "Most of this has been checked by someone independent."}
      </p>
    </div>
  );
}

export function TransparencyBar({ value, capped }: { value: number; capped?: boolean }) {
  return (
    <div className="rounded-3xl border-2 border-border bg-card p-4">
      <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Transparency
      </p>
      <p className="mt-2 text-3xl font-bold leading-none">{value}</p>
      <div className="mt-3 h-5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-sunflower transition-[width]"
          style={{ width: `${value}%` }}
        />
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        {capped
          ? "Capped at 20: a supplier is on an official banned list."
          : "How much the company actually tells you."}
      </p>
    </div>
  );
}
