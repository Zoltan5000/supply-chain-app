import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { brands, scoresFor } from "@/data/brands";
import { VerdictChip } from "./VerdictChip";

export function ComparePicker({ slug }: { slug: string }) {
  const [open, setOpen] = useState(false);
  const current = brands.find((b) => b.slug === slug);
  const others = brands
    .filter((b) => b.slug !== slug)
    .sort((x, y) => {
      const cx = /cotton/i.test(x.fiber) ? 0 : 1;
      const cy = /cotton/i.test(y.fiber) ? 0 : 1;
      return cx - cy;
    });

  return (
    <section className="mt-6">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full rounded-full bg-cobalt px-5 py-3 text-sm font-bold text-cobalt-foreground"
        aria-expanded={open}
      >
        {open ? "Close" : "Compare with another tee"}
      </button>
      {open && (
        <ul className="mt-3 space-y-2">
          {others.map((b) => (
            <li key={b.slug}>
              <Link
                to="/compare"
                search={{ a: slug, b: b.slug }}
                className="flex items-center justify-between gap-3 rounded-2xl bg-muted/60 p-3"
              >
                <span>
                  <span className="block text-sm font-bold">{b.brand}</span>
                  <span className="block text-xs text-muted-foreground">
                    {b.fiber} · {b.countryOfOrigin}
                    {current && b.fiber === current.fiber ? " · same fiber" : ""}
                  </span>
                </span>
                <VerdictChip verdict={scoresFor(b).verdict} size="sm" />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
