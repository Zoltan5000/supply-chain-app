import type { Evidence } from "@/data/brands";
import { cn } from "@/lib/utils";

export function ContextVsFindingBadge({ kind }: { kind: Evidence["kind"] }) {
  return (
    <span
      className={cn(
        "rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-widest",
        kind === "finding"
          ? "bg-cobalt text-cobalt-foreground"
          : "bg-sunflower text-sunflower-foreground",
      )}
    >
      {kind === "finding" ? "Verified finding" : "Context"}
    </span>
  );
}

const sourceTypeLabel: Record<Evidence["sourceType"], string> = {
  brand_claim: "Brand claim",
  independent_audit: "Independent audit",
  trade_record: "Trade record",
  news: "News / research",
  certification: "Certification",
  customs_shipment: "Customs shipment",
  official_list: "Official list",
};

export function EvidenceCard({ evidence }: { evidence: Evidence }) {
  return (
    <article className="rounded-2xl border-2 border-border bg-card p-4">
      <div className="flex flex-wrap items-center gap-2">
        <ContextVsFindingBadge kind={evidence.kind} />
        <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold">
          {sourceTypeLabel[evidence.sourceType]}
        </span>
        <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold">
          {evidence.independent ? "Independent" : "From the brand"}
        </span>
      </div>
      <h4 className="mt-2 text-base font-bold">{evidence.title}</h4>
      <p className="mt-1 text-sm text-muted-foreground">{evidence.body}</p>
      <p className="mt-2 text-[11px] text-muted-foreground">
        {evidence.sourceName} · {evidence.date}
      </p>
    </article>
  );
}
