import { nodeRisk, round, type TierNode } from "@/config/scoring";
import { cn } from "@/lib/utils";

const statusLabel: Record<TierNode["status"], string> = {
  known: "Known",
  estimated: "Estimated",
  unknown: "Unknown",
};

const statusStyle: Record<TierNode["status"], string> = {
  known: "bg-verdict-green-soft",
  estimated: "bg-verdict-amber-soft",
  unknown: "bg-verdict-grey-soft",
};

export function TierLadder({ tiers }: { tiers: TierNode[] }) {
  return (
    <ol className="space-y-2">
      {tiers.map((t) => {
        const risk = round(nodeRisk(t));
        const dashed = t.status !== "known";
        return (
          <li
            key={t.tier}
            className={cn(
              "rounded-2xl border-2 p-3",
              dashed ? "border-dashed" : "border-solid",
              t.status === "unknown" ? "bg-muted/40" : "bg-card",
            )}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                  Tier {t.tier} · {t.stage}
                </p>
                <p className="mt-0.5 truncate text-sm font-bold">
                  {t.actor ?? "Not disclosed"}
                </p>
                <p className="text-xs text-muted-foreground">
                  {t.country ?? "Country unknown"}
                </p>
              </div>
              <div className="shrink-0 text-right">
                <span
                  className={cn(
                    "inline-block rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide",
                    statusStyle[t.status],
                  )}
                >
                  {statusLabel[t.status]}
                </span>
                <p className="mt-1 text-lg font-bold leading-none">{risk}</p>
                <p className="text-[11px] text-muted-foreground">risk</p>
              </div>
            </div>
            {t.badges && t.badges.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {t.badges.map((b) => (
                  <span
                    key={b}
                    className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold"
                  >
                    {b}
                  </span>
                ))}
              </div>
            )}
            {t.status !== "known" && (
              <p className="mt-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                Estimated from country mix — not a fact about a named site
              </p>
            )}
            <p className="mt-1 text-[11px] text-muted-foreground">{t.sourceFootnote}</p>
          </li>
        );
      })}
    </ol>
  );
}
