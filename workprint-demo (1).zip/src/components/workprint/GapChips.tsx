import type { Gap } from "@/data/brands";
import { cn } from "@/lib/utils";

const severityStyle: Record<Gap["severity"], string> = {
  high: "bg-verdict-red-soft text-foreground",
  medium: "bg-verdict-amber-soft text-foreground",
  low: "bg-muted text-foreground",
};

export function GapChips({ gaps }: { gaps: Gap[] }) {
  if (gaps.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        Nothing major missing for this one.
      </p>
    );
  }
  return (
    <div className="flex flex-wrap gap-2">
      {gaps.map((g) => (
        <span
          key={g.id}
          title={g.whyItMatters}
          className={cn(
            "rounded-full px-3 py-1.5 text-sm font-semibold",
            severityStyle[g.severity],
          )}
        >
          {g.label}
        </span>
      ))}
    </div>
  );
}

export function GapList({ gaps }: { gaps: Gap[] }) {
  return (
    <ul className="space-y-2">
      {gaps.map((g) => (
        <li key={g.id} className="rounded-2xl bg-muted/60 p-3">
          <p className="text-sm font-bold">{g.label}</p>
          <p className="text-sm text-muted-foreground">{g.whyItMatters}</p>
        </li>
      ))}
    </ul>
  );
}
