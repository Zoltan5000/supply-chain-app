import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { cn } from "@/lib/utils";

export function QrSticker({
  payload,
  size = 72,
  className,
}: {
  payload: string;
  size?: number;
  className?: string;
}) {
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    QRCode.toDataURL(payload, { margin: 1, width: size * 3 })
      .then((url) => alive && setSrc(url))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [payload, size]);

  return (
    <div
      className={cn(
        "flex flex-col items-center gap-1 rounded-xl bg-card p-1.5 shadow-card",
        className,
      )}
      style={{ width: size + 12 }}
    >
      {src ? (
        <img src={src} alt={`QR code ${payload}`} width={size} height={size} />
      ) : (
        <div className="bg-muted" style={{ width: size, height: size }} />
      )}
      <span className="text-[9px] font-bold tracking-tight text-muted-foreground">
        {payload}
      </span>
    </div>
  );
}
