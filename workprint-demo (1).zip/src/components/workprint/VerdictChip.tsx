import type { Verdict } from "@/config/scoring";
import { VERDICT_COPY } from "@/config/scoring";
import { verdictStyles } from "@/lib/verdict";
import { cn } from "@/lib/utils";

export function VerdictChip({
  verdict,
  size = "lg",
  className,
}: {
  verdict: Verdict;
  size?: "sm" | "lg";
  className?: string;
}) {
  const s = verdictStyles[verdict];
  const copy = VERDICT_COPY[verdict];

  if (size === "sm") {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wide",
          s.chip,
          className,
        )}
      >
        {copy.title}
      </span>
    );
  }

  return (
    <div className={cn("rounded-3xl p-5", s.soft, className)}>
      <span
        className={cn(
          "inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-bold uppercase tracking-widest",
          s.chip,
        )}
      >
        {s.label}
      </span>
      <h2 className="mt-3 text-3xl leading-tight">{copy.title}</h2>
      <p className="mt-1 text-sm text-foreground/80">{copy.sentence}</p>
    </div>
  );
}
