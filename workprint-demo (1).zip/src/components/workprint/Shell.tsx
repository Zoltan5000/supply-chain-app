import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { DEMO_DISCLAIMER } from "@/config/scoring";

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto w-full max-w-[480px] px-4 pb-16 pt-5">
        <header className="mb-5 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-coral text-coral-foreground">
              <span className="text-sm font-black">V</span>
            </span>
            <span className="text-lg font-black tracking-tight">Vis-a-Vis</span>
          </Link>
          <nav className="flex items-center gap-3 text-xs font-bold text-muted-foreground">
            <Link to="/scan" className="hover:text-foreground">
              Scan
            </Link>
            <Link to="/methodology" className="hover:text-foreground">
              Method
            </Link>
          </nav>
        </header>
        {children}
      </div>
    </div>
  );
}

export function DemoFooter() {
  return (
    <footer className="mt-8 rounded-3xl bg-muted/70 p-4">
      <p className="text-xs text-muted-foreground">{DEMO_DISCLAIMER}</p>
      <a
        href="mailto:corrections@workprint.demo?subject=Correction%20request"
        className="mt-2 inline-block text-xs font-bold underline"
      >
        Request a correction
      </a>
    </footer>
  );
}
