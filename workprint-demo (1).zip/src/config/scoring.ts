/**
 * Workprint scoring — single source of truth.
 * The UI and the /methodology page both read from this file so the numbers
 * shown to a shopper and the formulas we publish can never drift apart.
 */

export type TierStatus = "known" | "estimated" | "unknown";
export type Verdict = "green" | "amber" | "red" | "grey";
export type Prevalence = "low" | "medium" | "high";
export type EntityCheck =
  | "checked_clear"
  | "partly_checked"
  | "not_checked"
  | "watchlist_hit";

export type SourceType =
  | "brand_claim"
  | "independent_audit"
  | "trade_record"
  | "news"
  | "certification"
  | "customs_shipment"
  | "official_list";

export type SourceConfidenceKind =
  | "verified"
  | "ngo_union"
  | "industry_context"
  | "proxy"
  | "unknown";

export interface CostFloorInputs {
  materials: number;
  laborHours: number;
  minWagePerHour: number;
  overhead: number;
  shipping: number;
}

export interface CountryMixEntry {
  country: string;
  share: number; // 0..1
  risk: number; // 0..100
}

export interface TierNode {
  tier: 0 | 1 | 2 | 3 | 4;
  stage: string;
  actor: string | null;
  country: string | null;
  status: TierStatus;
  declaredUnitPrice?: number;
  costFloor?: CostFloorInputs;
  location?: { dolList: boolean; prevalence: Prevalence };
  entityCheck?: EntityCheck;
  /** Precomputed inherited country-mix risk for Unknown / Estimated tiers. */
  countryMix?: CountryMixEntry[];
  badges?: string[];
  sourceFootnote: string;
}

export interface ConfidenceInputs {
  recentIndependentAuditOfFinalAssembly: boolean;
  finalAssemblyFacilityNamed: boolean;
  multipleIndependentSourceTypes: boolean;
  tier2Named: boolean;
  numericWageOrPriceData: boolean;
  evidenceYoungerThan12Months: boolean;
  fairPayDimensionMissing: boolean;
  onlyBrandOwnedSources: boolean;
  keySupplierIsTradingCompany: boolean;
  tier3Or4Unknown: boolean;
}

export interface ScorecardCategory {
  raw: number; // 0..100
  sourceConfidence: SourceConfidenceKind;
}

export interface TransparencyInputs {
  traceability: ScorecardCategory;
  laborHumanRights: ScorecardCategory;
  wageTransparency: ScorecardCategory;
  environment: ScorecardCategory;
  legalCompliance: ScorecardCategory;
  companyDisclosure: ScorecardCategory;
}

export interface WageInputs {
  estimatedWagePerHour: number;
  livingWagePerHour: number;
  laborMinutes: number;
}

export interface Factor {
  label: string;
  value: number;
}

export interface ScoreBreakdown {
  risk: number;
  confidence: number;
  transparency: number;
  verdict: Verdict;
  riskBand: "Low" | "Elevated" | "High";
  overrideApplied: boolean;
  greyRuleApplied: boolean;
  transparencyCapped: boolean;
  worstTier: TierNode | null;
  riskFactors: Factor[];
  confidenceFactors: Factor[];
  transparencyFactors: Factor[];
}

/* ------------------------------------------------------------------ */
/* Risk                                                                */
/* ------------------------------------------------------------------ */

export const RISK_WEIGHTS = {
  priceAnomaly: 0.4,
  locationRisk: 0.3,
  entityRisk: 0.3,
};

export const RISK_THRESHOLDS = { low: 35, high: 65 };

export const ENTITY_RISK_VALUES: Record<EntityCheck, number> = {
  checked_clear: 0,
  partly_checked: 30,
  not_checked: 50,
  watchlist_hit: 90,
};

export const ENTITY_RISK_LABELS: Record<EntityCheck, string> = {
  checked_clear: "Screened, no matches",
  partly_checked: "Partly screened",
  not_checked: "Not screened",
  watchlist_hit: "Watchlist or sanctions hit",
};

export const PREVALENCE_RISK: Record<Prevalence, number> = {
  low: 0,
  medium: 20,
  high: 40,
};

export const clamp = (n: number, min = 0, max = 100) =>
  Math.max(min, Math.min(max, n));

export const round = (n: number) => Math.round(n);

export function costFloor(i: CostFloorInputs): number {
  return i.materials + i.minWagePerHour * i.laborHours + i.overhead + i.shipping;
}

export function priceRatio(declaredUnitPrice: number, i: CostFloorInputs): number {
  const floor = costFloor(i);
  return floor === 0 ? 1 : declaredUnitPrice / floor;
}

export function priceAnomalyScore(
  declaredUnitPrice: number | undefined,
  i: CostFloorInputs | undefined,
): number {
  if (declaredUnitPrice === undefined || !i) return 50; // no price data = midpoint, never 0
  const ratio = priceRatio(declaredUnitPrice, i);
  if (ratio >= 1) return 0;
  return clamp(((1 - ratio) / 0.5) * 100);
}

export function locationRiskScore(
  loc: { dolList: boolean; prevalence: Prevalence } | undefined,
): number {
  if (!loc) return 40;
  return clamp((loc.dolList ? 60 : 0) + PREVALENCE_RISK[loc.prevalence]);
}

export function entityRiskScore(check: EntityCheck | undefined): number {
  return ENTITY_RISK_VALUES[check ?? "not_checked"];
}

export function inheritedCountryMixRisk(mix: CountryMixEntry[] | undefined): number {
  if (!mix || mix.length === 0) return 60; // unknown with no mix data is never treated as safe
  return clamp(mix.reduce((sum, m) => sum + m.share * m.risk, 0));
}

export function nodeRisk(node: TierNode): number {
  if (node.status === "unknown") return inheritedCountryMixRisk(node.countryMix);
  const pa = priceAnomalyScore(node.declaredUnitPrice, node.costFloor);
  const lr = locationRiskScore(node.location);
  const er = entityRiskScore(node.entityCheck);
  return clamp(
    RISK_WEIGHTS.priceAnomaly * pa +
      RISK_WEIGHTS.locationRisk * lr +
      RISK_WEIGHTS.entityRisk * er,
  );
}

export function riskBand(risk: number): "Low" | "Elevated" | "High" {
  if (risk < RISK_THRESHOLDS.low) return "Low";
  if (risk < RISK_THRESHOLDS.high) return "Elevated";
  return "High";
}

/* ------------------------------------------------------------------ */
/* Confidence                                                          */
/* ------------------------------------------------------------------ */

export const CONFIDENCE_RULES: {
  key: keyof ConfidenceInputs;
  value: number;
  label: string;
}[] = [
  {
    key: "recentIndependentAuditOfFinalAssembly",
    value: 25,
    label: "Independent audit of the sewing factory in the last 18 months",
  },
  {
    key: "finalAssemblyFacilityNamed",
    value: 20,
    label: "Sewing factory named with an address",
  },
  {
    key: "multipleIndependentSourceTypes",
    value: 15,
    label: "Two or more independent kinds of source agree",
  },
  { key: "tier2Named", value: 15, label: "Fabric mill named" },
  {
    key: "numericWageOrPriceData",
    value: 10,
    label: "Real wage or price numbers, not marketing copy",
  },
  { key: "evidenceYoungerThan12Months", value: 10, label: "Evidence is under a year old" },
  {
    key: "fairPayDimensionMissing",
    value: -20,
    label: "Nothing at all on fair pay or forced labor",
  },
  { key: "onlyBrandOwnedSources", value: -15, label: "Only the brand's own word" },
  {
    key: "keySupplierIsTradingCompany",
    value: -10,
    label: "A key supplier is a trading company with no factory named",
  },
  { key: "tier3Or4Unknown", value: -20, label: "Yarn or raw cotton is unknown" },
];

export const GREY_CONFIDENCE_FLOOR = 40;

export function computeConfidence(inputs: ConfidenceInputs): {
  score: number;
  factors: Factor[];
} {
  const factors: Factor[] = [];
  let total = 0;
  for (const rule of CONFIDENCE_RULES) {
    if (inputs[rule.key]) {
      total += rule.value;
      factors.push({ label: rule.label, value: rule.value });
    }
  }
  return { score: clamp(total), factors };
}

/* ------------------------------------------------------------------ */
/* Transparency                                                        */
/* ------------------------------------------------------------------ */

export const TIER_VISIBILITY_WEIGHTS: Record<1 | 2 | 3 | 4, number> = {
  1: 0.15,
  2: 0.2,
  3: 0.25,
  4: 0.4,
};

export const STATUS_CREDIT: Record<TierStatus, number> = {
  known: 1,
  estimated: 0.5,
  unknown: 0,
};

export const SCORECARD_WEIGHTS: Record<keyof TransparencyInputs, number> = {
  traceability: 0.2,
  laborHumanRights: 0.2,
  wageTransparency: 0.15,
  environment: 0.15,
  legalCompliance: 0.15,
  companyDisclosure: 0.15,
};

export const SCORECARD_LABELS: Record<keyof TransparencyInputs, string> = {
  traceability: "Traceability",
  laborHumanRights: "Labor & human rights",
  wageTransparency: "Wage transparency",
  environment: "Environment",
  legalCompliance: "Legal & compliance",
  companyDisclosure: "Company disclosure",
};

export const SOURCE_CONFIDENCE_MULTIPLIER: Record<SourceConfidenceKind, number> = {
  verified: 1,
  ngo_union: 0.85,
  industry_context: 0.7,
  proxy: 0.5,
  unknown: 0,
};

/** How tier visibility and the disclosure scorecard are blended. */
export const TRANSPARENCY_BLEND = { tierVisibility: 0.4, scorecard: 0.6 };
export const TRANSPARENCY_HARD_CAP = 20;

export function tierVisibilityScore(tiers: TierNode[]): number {
  let total = 0;
  for (const t of [1, 2, 3, 4] as const) {
    const node = tiers.find((n) => n.tier === t);
    const credit = node ? STATUS_CREDIT[node.status] : 0;
    total += TIER_VISIBILITY_WEIGHTS[t] * credit;
  }
  return clamp(total * 100);
}

export function scorecardScore(inputs: TransparencyInputs): number {
  let total = 0;
  (Object.keys(SCORECARD_WEIGHTS) as (keyof TransparencyInputs)[]).forEach((key) => {
    const cat = inputs[key];
    total +=
      SCORECARD_WEIGHTS[key] * cat.raw * SOURCE_CONFIDENCE_MULTIPLIER[cat.sourceConfidence];
  });
  return clamp(total);
}

/* ------------------------------------------------------------------ */
/* Wage block                                                          */
/* ------------------------------------------------------------------ */

export function wageRatio(w: WageInputs) {
  return w.livingWagePerHour === 0 ? 1 : w.estimatedWagePerHour / w.livingWagePerHour;
}

export function wageScore(w: WageInputs, confidence: number) {
  return clamp(100 * Math.min(1, wageRatio(w)) * (confidence / 100));
}

export function livingWageGapPerProduct(w: WageInputs) {
  return Math.max(
    0,
    ((w.livingWagePerHour - w.estimatedWagePerHour) * w.laborMinutes) / 60,
  );
}

/* ------------------------------------------------------------------ */
/* Full product score                                                  */
/* ------------------------------------------------------------------ */

export interface ScoreSubject {
  tiers: TierNode[];
  confidenceInputs: ConfidenceInputs;
  transparencyInputs: TransparencyInputs;
  flags: { uflpaEntityMatch: boolean; cbpWroActive: boolean };
}

export const OVERRIDE_RISK = 90;

export function computeScores(subject: ScoreSubject): ScoreBreakdown {
  const { tiers, flags } = subject;
  const override = flags.uflpaEntityMatch || flags.cbpWroActive;

  const riskFactors: Factor[] = tiers.map((t) => ({
    label: `Tier ${t.tier} · ${t.stage}${t.status === "unknown" ? " (unknown, estimated)" : ""}`,
    value: round(nodeRisk(t)),
  }));

  const worstValue = riskFactors.reduce((m, f) => Math.max(m, f.value), 0);
  const worstTier =
    tiers.find((t) => round(nodeRisk(t)) === worstValue) ?? tiers[0] ?? null;

  const risk = override ? OVERRIDE_RISK : round(worstValue);

  const { score: confidence, factors: confidenceFactors } = computeConfidence(
    subject.confidenceInputs,
  );

  const visibility = tierVisibilityScore(tiers);
  const scorecard = scorecardScore(subject.transparencyInputs);
  let transparency = round(
    TRANSPARENCY_BLEND.tierVisibility * visibility +
      TRANSPARENCY_BLEND.scorecard * scorecard,
  );

  const band = riskBand(risk);
  const transparencyCapped =
    (band === "High" || override) && transparency > TRANSPARENCY_HARD_CAP;
  if (transparencyCapped) transparency = TRANSPARENCY_HARD_CAP;

  const greyRuleApplied = !override && confidence < GREY_CONFIDENCE_FLOOR;

  let verdict: Verdict;
  if (override || band === "High") verdict = "red";
  else if (greyRuleApplied) verdict = "grey";
  else if (band === "Low") verdict = "green";
  else verdict = "amber";

  return {
    risk,
    confidence,
    transparency,
    verdict,
    riskBand: band,
    overrideApplied: override,
    greyRuleApplied,
    transparencyCapped,
    worstTier,
    riskFactors,
    confidenceFactors,
    transparencyFactors: [
      { label: "Tier visibility (upstream weighted)", value: round(visibility) },
      { label: "Disclosure scorecard", value: round(scorecard) },
    ],
  };
}

export const VERDICT_COPY: Record<Verdict, { title: string; sentence: string }> = {
  green: {
    title: "Looks clean",
    sentence: "Low risk, and enough checked information to say so.",
  },
  amber: {
    title: "Some risk",
    sentence: "There are open questions in this supply chain worth knowing about.",
  },
  red: {
    title: "High risk",
    sentence: "Serious forced-labor risk, or a match on an official banned list.",
  },
  grey: {
    title: "Not enough to judge",
    sentence: "We don't have enough checked information to call this one either way.",
  },
};

export const DEMO_DISCLAIMER =
  "Internal demo with seed data. Not a public accusation. Risk indicator, not proof.";
