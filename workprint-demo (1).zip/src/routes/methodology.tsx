import { createFileRoute, Link } from "@tanstack/react-router";
import {
  CONFIDENCE_RULES,
  ENTITY_RISK_LABELS,
  ENTITY_RISK_VALUES,
  GREY_CONFIDENCE_FLOOR,
  OVERRIDE_RISK,
  PREVALENCE_RISK,
  RISK_THRESHOLDS,
  RISK_WEIGHTS,
  SCORECARD_LABELS,
  SCORECARD_WEIGHTS,
  SOURCE_CONFIDENCE_MULTIPLIER,
  STATUS_CREDIT,
  TIER_VISIBILITY_WEIGHTS,
  TRANSPARENCY_BLEND,
  TRANSPARENCY_HARD_CAP,
  type EntityCheck,
  type Prevalence,
  type SourceConfidenceKind,
  type TransparencyInputs,
} from "@/config/scoring";
import { brands, scoresFor } from "@/data/brands";
import { Shell, DemoFooter } from "@/components/workprint/Shell";
import { VerdictChip } from "@/components/workprint/VerdictChip";

export const Route = createFileRoute("/methodology")({
  head: () => ({
    meta: [
      { title: "How Vis-a-Vis scores a t-shirt" },
      {
        name: "description",
        content:
          "The exact weights, thresholds and rules behind the risk, confidence and transparency scores — including the grey rule and the banned-list override.",
      },
      { property: "og:title", content: "How Vis-a-Vis scores a t-shirt" },
      {
        property: "og:description",
        content: "Every weight and threshold behind the three scores, in the open.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Methodology,
});

function Row({ label, value }: { label: string; value: string | number }) {
  return (
    <li className="flex justify-between gap-3 border-b border-border py-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-bold">{value}</span>
    </li>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-6 rounded-3xl border-2 border-border bg-card p-4">
      <h2 className="text-xl">{title}</h2>
      <div className="mt-2 text-sm">{children}</div>
    </section>
  );
}

function Formula({ children }: { children: React.ReactNode }) {
  return (
    <pre className="mt-2 overflow-x-auto rounded-2xl bg-muted p-3 text-xs leading-relaxed">
      {children}
    </pre>
  );
}

function Methodology() {
  return (
    <Shell>
      <h1 className="text-3xl">How we score a t-shirt</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Every number on a result page comes out of the rules below. This page reads those
        weights straight out of the same file the scores use, so it can't drift.
      </p>

      <Block title="Risk (0–100) — higher means more forced-labor risk">
        <p className="text-muted-foreground">
          We score every step of the chain and then take the <strong>worst</strong> one,
          never the average. One bad step is enough to matter.
        </p>
        <Formula>{`Cost floor    = materials + (minimum wage/hr × labor hours) + overhead + shipping
Price ratio   = declared unit price ÷ cost floor
Price anomaly = 0 if ratio ≥ 1, else min(100, (1 − ratio) ÷ 0.5 × 100)

Node risk = ${RISK_WEIGHTS.priceAnomaly} × price anomaly
          + ${RISK_WEIGHTS.locationRisk} × place risk
          + ${RISK_WEIGHTS.entityRisk} × screening risk

Product risk = worst node risk across the chain
               (unknown steps use their inherited country-mix risk)`}</Formula>

        <h3 className="mt-4 text-base font-bold">Place risk</h3>
        <ul className="mt-1">
          <Row label="Product country on the official forced/child labor goods list" value="+60" />
          {(Object.keys(PREVALENCE_RISK) as Prevalence[]).map((p) => (
            <Row key={p} label={`${p} regional prevalence`} value={`+${PREVALENCE_RISK[p]}`} />
          ))}
          <Row label="Capped at" value={100} />
        </ul>

        <h3 className="mt-4 text-base font-bold">Screening risk</h3>
        <ul className="mt-1">
          {(Object.keys(ENTITY_RISK_VALUES) as EntityCheck[]).map((k) => (
            <Row key={k} label={ENTITY_RISK_LABELS[k]} value={ENTITY_RISK_VALUES[k]} />
          ))}
        </ul>

        <h3 className="mt-4 text-base font-bold">Unknown steps</h3>
        <p className="text-muted-foreground">
          An unknown step is not scored as zero. It inherits the risk of the countries
          that typically supply that step on this trade lane, worked out in advance in the
          seed data as the sum of (share of imports from a country × that country's risk).
          No live trade data is fetched.
        </p>

        <h3 className="mt-4 text-base font-bold">Bands</h3>
        <ul className="mt-1">
          <Row label="Low" value={`under ${RISK_THRESHOLDS.low}`} />
          <Row label="Elevated" value={`${RISK_THRESHOLDS.low}–${RISK_THRESHOLDS.high - 1}`} />
          <Row label="High" value={`${RISK_THRESHOLDS.high} and above`} />
        </ul>
        <p className="mt-2 rounded-2xl bg-verdict-amber-soft p-3 text-xs font-bold">
          These thresholds are a draft, pending legal review.
        </p>
      </Block>

      <Block title="The banned-list override">
        <p className="text-muted-foreground">
          If a supplier matches the UFLPA entity list, or an active CBP withhold release
          order applies, the result is forced to risk {OVERRIDE_RISK} and a High / Red
          verdict whatever the rest of the maths says. Transparency is also capped at{" "}
          {TRANSPARENCY_HARD_CAP}.
        </p>
      </Block>

      <Block title="Confidence (0–100) — how much of this is actually checked">
        <p className="text-muted-foreground">
          Confidence is not "how ethical". It's how much of the answer has been verified
          rather than estimated. Every result starts at zero.
        </p>
        <ul className="mt-2">
          {CONFIDENCE_RULES.map((r) => (
            <Row
              key={r.key}
              label={r.label}
              value={r.value > 0 ? `+${r.value}` : r.value}
            />
          ))}
        </ul>
        <p className="mt-3 rounded-2xl bg-verdict-grey-soft p-3 text-xs font-bold">
          The grey rule: below {GREY_CONFIDENCE_FLOOR} confidence the verdict turns grey
          no matter how low the risk number is. Green needs low risk <em>and</em>{" "}
          confidence of at least {GREY_CONFIDENCE_FLOOR}. Thin information must never look
          safe.
        </p>
      </Block>

      <Block title="Transparency (0–100) — how much the company tells you">
        <p className="text-muted-foreground">
          Two halves: how much of the chain is visible, and how much the company
          discloses. Upstream steps count for more because they are harder and riskier.
        </p>
        <h3 className="mt-3 text-base font-bold">Chain visibility weights</h3>
        <ul className="mt-1">
          {([1, 2, 3, 4] as const).map((t) => (
            <Row
              key={t}
              label={`Tier ${t}`}
              value={`${Math.round(TIER_VISIBILITY_WEIGHTS[t] * 100)}%`}
            />
          ))}
        </ul>
        <p className="mt-2 text-muted-foreground">
          Known counts for {STATUS_CREDIT.known * 100}% of its weight, estimated{" "}
          {STATUS_CREDIT.estimated * 100}%, unknown {STATUS_CREDIT.unknown}%.
        </p>

        <h3 className="mt-4 text-base font-bold">Disclosure scorecard</h3>
        <ul className="mt-1">
          {(Object.keys(SCORECARD_WEIGHTS) as (keyof TransparencyInputs)[]).map((k) => (
            <Row
              key={k}
              label={SCORECARD_LABELS[k]}
              value={`${Math.round(SCORECARD_WEIGHTS[k] * 100)}%`}
            />
          ))}
        </ul>

        <h3 className="mt-4 text-base font-bold">Source confidence multipliers</h3>
        <ul className="mt-1">
          {(Object.keys(SOURCE_CONFIDENCE_MULTIPLIER) as SourceConfidenceKind[]).map(
            (k) => (
              <Row
                key={k}
                label={k.replace(/_/g, " / ")}
                value={SOURCE_CONFIDENCE_MULTIPLIER[k]}
              />
            ),
          )}
        </ul>

        <Formula>{`Transparency = ${TRANSPARENCY_BLEND.tierVisibility} × chain visibility
             + ${TRANSPARENCY_BLEND.scorecard} × disclosure scorecard

Hard cap ${TRANSPARENCY_HARD_CAP} if the verdict is High or a listed supplier exists.`}</Formula>
      </Block>

      <Block title="Pay (supporting, not a fourth score)">
        <Formula>{`Wage ratio        = estimated wage ÷ living wage
Wage score        = 100 × min(1, wage ratio) × confidence
Living-wage gap   = (living wage/hr − actual wage/hr) × labor minutes ÷ 60`}</Formula>
        <p className="mt-2 text-muted-foreground">
          We score what a company discloses. We never say a company underpays unless the
          evidence is direct and checked by a human reviewer.
        </p>
      </Block>

      <Block title="What each demo tee scores">
        <ul className="space-y-2">
          {brands.map((b) => {
            const s = scoresFor(b);
            return (
              <li key={b.slug}>
                <Link
                  to="/p/$slug"
                  params={{ slug: b.slug }}
                  className="flex items-center justify-between gap-3 rounded-2xl bg-muted/60 p-3"
                >
                  <span className="min-w-0">
                    <span className="block text-sm font-bold">{b.brand}</span>
                    <span className="block text-xs text-muted-foreground">
                      Risk {s.risk} · Confidence {s.confidence} · Transparency{" "}
                      {s.transparency}
                    </span>
                  </span>
                  <VerdictChip verdict={s.verdict} size="sm" />
                </Link>
              </li>
            );
          })}
        </ul>
      </Block>

      <DemoFooter />
    </Shell>
  );
}
