import { createFileRoute } from "@tanstack/react-router";
import { Shell, DemoFooter } from "@/components/workprint/Shell";

export const Route = createFileRoute("/sources")({
  head: () => ({
    meta: [
      { title: "Sources — Vis-a-Vis" },
      {
        name: "description",
        content: "The kinds of sources behind Vis-a-Vis scores, what each can prove, and what comes later.",
      },
      { property: "og:title", content: "Sources — Vis-a-Vis" },
      {
        property: "og:description",
        content: "What each source type can and cannot prove about a cotton tee's supply chain.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Sources,
});

const SEED = [
  ["Brand claims", "What the brand says about itself.", "Useful as a starting point. Never proof on its own."],
  ["Independent audits", "A third party visited the factory.", "Shows conditions on the audit day. Can miss hidden or subcontracted work."],
  ["Trade records", "Shipping paperwork between companies.", "Shows who sold to whom. Says nothing about working conditions."],
  ["News reports", "Journalism about a company or region.", "Can surface problems. We only flag a named company after a person has checked it."],
  ["Certifications", "Labels like organic or fair-trade schemes.", "Shows a standard was claimed and checked. Coverage varies by scheme."],
  ["Customs shipments", "Goods seen crossing a border.", "Helps trace routes. Can't see what happened before the goods shipped."],
  ["Official lists", "Government banned-entity and forced-labor lists.", "A verified match turns the result red automatically."],
];

const LATER = [
  ["Sayari", "Company ownership and link data, to spot hidden parents and trading fronts."],
  ["Tradeverifyd", "Supplier and shipment mapping, to fill in fabric, yarn and cotton tiers."],
  ["Web research", "Automated searching of news and reports, always reviewed by a person before it shows."],
];

function Sources() {
  return (
    <Shell>
      <h1 className="text-3xl leading-tight">Where our information comes from</h1>
      <div className="mt-3 rounded-3xl bg-sunflower/25 p-4">
        <p className="text-sm font-bold">This version runs on demo data.</p>
        <p className="text-sm text-muted-foreground">
          All five brands and their sources are made up for internal demos. Nothing here is a
          finding about a real company.
        </p>
      </div>

      <h3 className="mt-6 text-xl">Kinds of source we use</h3>
      <ul className="mt-2 space-y-2">
        {SEED.map(([name, what, limits]) => (
          <li key={name} className="rounded-2xl bg-muted/60 p-3">
            <p className="text-sm font-bold">{name}</p>
            <p className="text-sm">{what}</p>
            <p className="text-sm text-muted-foreground">{limits}</p>
          </li>
        ))}
      </ul>

      <h3 className="mt-6 text-xl">Coming later</h3>
      <p className="text-sm text-muted-foreground">Planned, not connected yet.</p>
      <ul className="mt-2 space-y-2">
        {LATER.map(([name, what]) => (
          <li key={name} className="rounded-2xl border-2 border-dashed border-border p-3">
            <p className="text-sm font-bold">{name}</p>
            <p className="text-sm text-muted-foreground">{what}</p>
          </li>
        ))}
      </ul>

      <DemoFooter />
    </Shell>
  );
}
