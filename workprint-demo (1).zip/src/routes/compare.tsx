import { createFileRoute, Link } from "@tanstack/react-router";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import {
  nodeRisk,
  round,
  SCORECARD_LABELS,
  SOURCE_CONFIDENCE_MULTIPLIER,
  type TransparencyInputs,
} from "@/config/scoring";
import { getBrand, scoresFor, type Brand } from "@/data/brands";
import { Shell, DemoFooter } from "@/components/workprint/Shell";
import { VerdictChip } from "@/components/workprint/VerdictChip";
import { GapChips } from "@/components/workprint/GapChips";
import { verdictStyles } from "@/lib/verdict";
import { cn } from "@/lib/utils";

const searchSchema = z.object({
  a: fallback(z.string(), "").default(""),
  b: fallback(z.string(), "").default(""),
});

export const Route = createFileRoute("/compare")({
  validateSearch: zodValidator(searchSchema),
  head: () => ({
    meta: [
      { title: "Compare two tees — Vis-a-Vis" },
      {
        name: "description",
        content: "Side-by-side forced-labor risk, confidence and transparency for two demo cotton tees.",
      },
      { property: "og:title", content: "Compare two tees — Vis-a-Vis" },
      {
        property: "og:description",
        content: "See which supply chain is riskier, and what each brand leaves unknown.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Compare,
});

interface Delta {
  label: string;
  a: number;
  b: number;
  unit: string;
}

function deltas(a: Brand, b: Brand): Delta[] {
  const out: Delta[] = [];
  for (const t of [0, 1, 2, 3, 4] as const) {
    const na = a.tiers.find((n) => n.tier === t);
    const nb = b.tiers.find((n) => n.tier === t);
    if (!na || !nb) continue;
    out.push({
      label: `Tier ${t} · ${na.stage} risk`,
      a: round(nodeRisk(na)),
      b: round(nodeRisk(nb)),
      unit: "risk",
    });
  }
  (Object.keys(SCORECARD_LABELS) as (keyof TransparencyInputs)[]).forEach((k) => {
    const ca = a.transparencyInputs[k];
    const cb = b.transparencyInputs[k];
    out.push({
      label: `${SCORECARD_LABELS[k]} disclosure`,
      a: round(ca.raw * SOURCE_CONFIDENCE_MULTIPLIER[ca.sourceConfidence]),
      b: round(cb.raw * SOURCE_CONFIDENCE_MULTIPLIER[cb.sourceConfidence]),
      unit: "disclosure",
    });
  });
  return out.sort((x, y) => Math.abs(y.a - y.b) - Math.abs(x.a - x.b)).slice(0, 3);
}

function Missing() {
  return (
    <Shell>
      <h1 className="text-2xl">Pick two tees to compare</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Open any result and tap “Compare with another tee”.
      </p>
      <Link to="/" className="mt-4 inline-block font-bold underline">
        Back to the demo shelf
      </Link>
      <DemoFooter />
    </Shell>
  );
}

function Row({ label, a, b, hint }: { label: string; a: number; b: number; hint: string }) {
  return (
    <div className="rounded-2xl bg-muted/60 p-3">
      <div className="flex items-baseline justify-between">
        <p className="text-sm font-bold">{label}</p>
        <p className="text-xs text-muted-foreground">{hint}</p>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-3">
        {[a, b].map((v, i) => (
          <div key={i}>
            <p className="display text-2xl">{v}</p>
            <div className="mt-1 h-2 rounded-full bg-background">
              <div
                className={cn("h-2 rounded-full", i === 0 ? "bg-coral" : "bg-cobalt")}
                style={{ width: `${v}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Compare() {
  const { a: sa, b: sb } = Route.useSearch();
  const a = getBrand(sa);
  const b = getBrand(sb);
  if (!a || !b || a.slug === b.slug) return <Missing />;
  const A = scoresFor(a);
  const B = scoresFor(b);
  const top = deltas(a, b);
  const aIds = new Set(a.gaps.map((g) => g.id));
  const bIds = new Set(b.gaps.map((g) => g.id));
  const onlyA = a.gaps.filter((g) => !bIds.has(g.id));
  const onlyB = b.gaps.filter((g) => !aIds.has(g.id));

  return (
    <Shell>
      <Link to="/p/$slug" params={{ slug: a.slug }} className="text-xs font-bold text-muted-foreground">
        ← Back to {a.brand}
      </Link>
      <h1 className="mt-2 text-2xl leading-tight">
        {a.brand} <span className="text-muted-foreground">vs</span> {b.brand}
      </h1>

      <div className="mt-4 grid grid-cols-2 gap-3">
        {[
          { br: a, s: A },
          { br: b, s: B },
        ].map(({ br, s }) => (
          <Link
            key={br.slug}
            to="/p/$slug"
            params={{ slug: br.slug }}
            className={cn("rounded-3xl p-3", verdictStyles[s.verdict].soft)}
          >
            <img src={br.image} alt={br.brand} className="aspect-square w-full rounded-2xl object-cover" />
            <p className="mt-2 text-sm font-bold leading-tight">{br.brand}</p>
            <VerdictChip verdict={s.verdict} size="sm" className="mt-2" />
          </Link>
        ))}
      </div>

      <section className="mt-6 space-y-2">
        <h3 className="text-xl">The three scores</h3>
        <Row label="Risk" a={A.risk} b={B.risk} hint="lower is better" />
        <Row label="Confidence" a={A.confidence} b={B.confidence} hint="how sure we are" />
        <Row label="Transparency" a={A.transparency} b={B.transparency} hint="higher is better" />
      </section>

      <section className="mt-6 space-y-2">
        <h3 className="text-xl">Biggest differences</h3>
        <p className="text-sm text-muted-foreground">
          The three tiers or disclosure areas where these two are furthest apart.
        </p>
        {top.map((d) => (
          <Row
            key={d.label}
            label={d.label}
            a={d.a}
            b={d.b}
            hint={d.unit === "risk" ? "lower is better" : "higher is better"}
          />
        ))}
      </section>

      <section className="mt-6">
        <h3 className="text-xl">Only missing for {a.brand}</h3>
        <div className="mt-2">
          <GapChips gaps={onlyA} />
        </div>
        <h3 className="mt-4 text-xl">Only missing for {b.brand}</h3>
        <div className="mt-2">
          <GapChips gaps={onlyB} />
        </div>
      </section>

      <p className="mt-6 text-xs text-muted-foreground">
        Brand-level comparison, not a claim about any single shirt or factory.
      </p>
      <DemoFooter />
    </Shell>
  );
}
