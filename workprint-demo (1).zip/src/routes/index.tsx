import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { brands, findBrand, scoresFor } from "@/data/brands";
import { Shell } from "@/components/workprint/Shell";
import { QrSticker } from "@/components/workprint/QrSticker";
import { VerdictChip } from "@/components/workprint/VerdictChip";
import { accentStyles } from "@/lib/verdict";
import { DEMO_DISCLAIMER } from "@/config/scoring";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Vis-a-Vis — Visibility for consumers" },
      {
        name: "description",
        content:
          "Scan a garment label or type a brand and see forced-labor risk, how confident the answer is, and what the company still hasn't told anyone.",
      },
      { property: "og:title", content: "Vis-a-Vis — Visibility for consumers" },
      {
        property: "og:description",
        content:
          "Scan a label, see the risk, the confidence, and the gaps in a cotton tee supply chain.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [coo, setCoo] = useState("");
  const [fiber, setFiber] = useState("");
  const [notFound, setNotFound] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const match = findBrand(query);
    if (match) {
      setNotFound(false);
      navigate({ to: "/p/$slug", params: { slug: match.slug } });
    } else {
      setNotFound(true);
    }
  };

  return (
    <Shell>
      <section className="rounded-4xl bg-coral p-6 text-coral-foreground">
        <h1 className="text-4xl leading-[1.05]">
          Visibility
          <br /> for consumers.
        </h1>
        <p className="mt-2 text-sm opacity-90">
          Scan the label. We'll show the forced-labor risk, how sure we are, and what
          nobody has told you yet.
        </p>
        <Link
          to="/scan"
          className="mt-5 flex w-full items-center justify-center rounded-2xl bg-foreground px-5 py-4 text-base font-black text-background"
        >
          Scan a label
        </Link>
      </section>

      <form onSubmit={submit} className="mt-4 rounded-3xl border-2 border-border bg-card p-4">
        <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
          Or type a brand or RN number
        </label>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          maxLength={80}
          placeholder="e.g. Northloop Basics or RN 132477"
          className="mt-2 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 text-base outline-none focus:border-cobalt"
        />
        <div className="mt-3 grid grid-cols-2 gap-2">
          <input
            value={coo}
            onChange={(e) => setCoo(e.target.value)}
            maxLength={40}
            placeholder="Country of origin"
            className="rounded-2xl border-2 border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-cobalt"
          />
          <input
            value={fiber}
            onChange={(e) => setFiber(e.target.value)}
            maxLength={40}
            placeholder="Fiber (optional)"
            className="rounded-2xl border-2 border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-cobalt"
          />
        </div>
        <button
          type="submit"
          className="mt-3 w-full rounded-2xl bg-cobalt px-4 py-3 text-sm font-black text-cobalt-foreground"
        >
          Look it up
        </button>
        {notFound && (
          <p className="mt-3 rounded-2xl bg-verdict-grey-soft p-3 text-sm">
            No match in this demo. We never invent a company — pick one of the five demo
            tees below instead.
          </p>
        )}
      </form>

      <section className="mt-6">
        <h2 className="text-xl">Demo shelf</h2>
        <p className="text-sm text-muted-foreground">
          Five fictional cotton tees. Scan the sticker or tap a card.
        </p>
        <div className="mt-3 space-y-3">
          {brands.map((b) => {
            const s = scoresFor(b);
            return (
              <Link
                key={b.slug}
                to="/p/$slug"
                params={{ slug: b.slug }}
                className={`flex gap-3 rounded-3xl p-3 ${accentStyles[b.accent]}`}
              >
                <img
                  src={b.image}
                  alt={`${b.brand} ${b.productName}`}
                  loading="lazy"
                  width={816}
                  height={816}
                  className="h-24 w-24 shrink-0 rounded-2xl object-cover"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-base font-black leading-tight">{b.brand}</p>
                  <p className="text-xs text-muted-foreground">
                    {b.productName} · {b.countryOfOrigin} · {b.rn}
                  </p>
                  <p className="mt-1 line-clamp-2 text-xs">{b.blurb}</p>
                  <div className="mt-2">
                    <VerdictChip verdict={s.verdict} size="sm" />
                  </div>
                </div>
                <QrSticker payload={b.qrPayload} size={56} className="self-center" />
              </Link>
            );
          })}
        </div>
      </section>

      <p className="mt-6 text-xs text-muted-foreground">{DEMO_DISCLAIMER}</p>
    </Shell>
  );
}
