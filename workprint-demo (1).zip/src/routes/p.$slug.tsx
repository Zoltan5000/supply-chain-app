import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import {
  costFloor,
  entityRiskScore,
  ENTITY_RISK_LABELS,
  livingWageGapPerProduct,
  locationRiskScore,
  priceAnomalyScore,
  priceRatio,
  RISK_WEIGHTS,
  round,
  wageRatio,
  wageScore,
} from "@/config/scoring";
import { getBrand, scoresFor, shopperEvidence } from "@/data/brands";
import { Shell, DemoFooter } from "@/components/workprint/Shell";
import { VerdictChip } from "@/components/workprint/VerdictChip";
import { ScoreTriple } from "@/components/workprint/ScoreTriple";
import { GapChips } from "@/components/workprint/GapChips";
import { TierLadder } from "@/components/workprint/TierLadder";
import { EvidenceCard } from "@/components/workprint/EvidenceCard";
import { verdictStyles } from "@/lib/verdict";
import { ComparePicker } from "@/components/workprint/ComparePicker";

export const Route = createFileRoute("/p/$slug")({
  loader: ({ params }) => {
    const brand = getBrand(params.slug);
    if (!brand) throw notFound();
    return { slug: params.slug };
  },
  head: ({ params }) => {
    const brand = getBrand(params.slug);
    const title = brand
      ? `${brand.brand} ${brand.productName} — Vis-a-Vis result`
      : "Result — Vis-a-Vis";
    const description = brand
      ? `${brand.brand}: forced-labor risk, confidence and transparency for a ${brand.fiber} tee made in ${brand.countryOfOrigin}.`
      : "Supply-chain result for a demo cotton tee.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: Result,
});

function Section({
  title,
  children,
  sub,
}: {
  title: string;
  sub?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-6">
      <h3 className="text-xl">{title}</h3>
      {sub && <p className="mb-2 text-sm text-muted-foreground">{sub}</p>}
      <div className="mt-2">{children}</div>
    </section>
  );
}

function Result() {
  const { slug } = Route.useLoaderData();
  const brand = getBrand(slug)!;
  const scores = scoresFor(brand);
  const evidence = shopperEvidence(brand);
  const findings = evidence.filter((e) => e.kind === "finding");
  const context = evidence.filter((e) => e.kind === "context");
  const t1 = brand.tiers.find((t) => t.tier === 1);
  const wageGap = livingWageGapPerProduct(brand.wage);

  return (
    <Shell>
      <Link to="/" className="text-xs font-bold text-muted-foreground">
        ← Back
      </Link>

      <div className="mt-2 overflow-hidden rounded-3xl">
        <img
          src={brand.image}
          alt={`${brand.brand} ${brand.productName}`}
          width={816}
          height={816}
          className="aspect-[4/3] w-full object-cover"
        />
      </div>
      <div className="mt-3">
        <h1 className="text-2xl leading-tight">{brand.brand}</h1>
        <p className="text-sm text-muted-foreground">
          {brand.productName} · {brand.fiber} · Made in {brand.countryOfOrigin} ·{" "}
          {brand.rn}
        </p>
      </div>

      <div className="mt-3">
        <VerdictChip verdict={scores.verdict} />
      </div>

      {scores.overrideApplied && (
        <div className="mt-3 rounded-3xl border-2 border-verdict-red bg-verdict-red-soft p-4">
          <p className="text-xs font-black uppercase tracking-widest text-verdict-red">
            Official banned-list match
          </p>
          <p className="mt-1 text-sm">
            A human reviewer confirmed a supplier in this chain matches an official
            forced-labor entity list. That forces a High / Red result no matter what the
            other numbers say, and caps transparency at 20.
          </p>
        </div>
      )}

      {scores.greyRuleApplied && (
        <div className="mt-3 rounded-3xl border-2 border-border bg-verdict-grey-soft p-4">
          <p className="text-xs font-black uppercase tracking-widest">Grey, on purpose</p>
          <p className="mt-1 text-sm">
            Confidence is {scores.confidence} out of 100, below our floor of 40. Thin
            information never gets to look safe, so the verdict stays grey even though the
            risk number is {scores.risk}.
          </p>
        </div>
      )}

      <div className="mt-4">
        <ScoreTriple scores={scores} />
      </div>

      <Section title="What's missing" sub="The holes that would change this answer.">
        <GapChips gaps={brand.gaps} />
      </Section>

      <Section
        title="The chain, step by step"
        sub="Tier 0 is the brand. Tier 4 is the cotton field — usually the riskiest and the least known."
      >
        <TierLadder tiers={brand.tiers} />
      </Section>

      {brand.suppliers.length > 0 && (
        <Section title="Suppliers we can name">
          <ul className="space-y-2">
            {brand.suppliers.map((s) => (
              <li
                key={s.name}
                className="rounded-2xl border-2 border-border bg-card p-3"
              >
                <div className="flex items-baseline justify-between gap-2">
                  <p className="text-sm font-bold">{s.name}</p>
                  <span className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                    Tier {s.tier}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {s.country} · {s.screenStatus}
                </p>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {s.badges.map((b) => (
                    <span
                      key={b}
                      className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold"
                    >
                      {b}
                    </span>
                  ))}
                </div>
              </li>
            ))}
          </ul>
        </Section>
      )}

      <Section
        title="What we found"
        sub="Checked findings first. General industry context is kept separate and clearly labelled."
      >
        <div className="space-y-3">
          {findings.map((e) => (
            <EvidenceCard key={e.id} evidence={e} />
          ))}
          {findings.length === 0 && (
            <p className="text-sm text-muted-foreground">
              Nothing here has been independently checked yet.
            </p>
          )}
        </div>
        {context.length > 0 && (
          <div className="mt-4 space-y-3">
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
              Industry context — not a finding about any named company
            </p>
            {context.map((e) => (
              <EvidenceCard key={e.id} evidence={e} />
            ))}
          </div>
        )}
      </Section>

      <Section title="Pay, as far as anyone has disclosed">
        <div className="rounded-3xl border-2 border-border bg-card p-4">
          <p className="text-sm">
            Disclosed pay is about {Math.round(wageRatio(brand.wage) * 100)}% of a living
            wage estimate for the country where the shirt is sewn. Weighted by how much we
            trust the evidence, that scores{" "}
            <strong>{round(wageScore(brand.wage, scores.confidence))}</strong> out of 100.
          </p>
          <p className="mt-2 text-sm text-muted-foreground">
            Living-wage gap on this shirt: about ${wageGap.toFixed(2)} of unpaid
            difference across {brand.wage.laborMinutes} minutes of sewing. We score what
            the company discloses, not what we assume it pays.
          </p>
        </div>
      </Section>

      <Section title="How this was calculated">
        <div className="space-y-3 rounded-3xl border-2 border-border bg-card p-4 text-sm">
          <div>
            <p className="font-bold">Risk {scores.risk} — {scores.riskBand}</p>
            <p className="text-muted-foreground">
              {scores.overrideApplied
                ? "Forced to 90 by the official banned-list match."
                : `We take the worst step in the chain, not the average. Worst here: ${scores.worstTier?.stage ?? "unknown"}.`}
            </p>
            <ul className="mt-1 space-y-0.5">
              {scores.riskFactors.map((f) => (
                <li key={f.label} className="flex justify-between gap-3">
                  <span className="text-muted-foreground">{f.label}</span>
                  <span className="font-bold">{f.value}</span>
                </li>
              ))}
            </ul>
            {t1?.costFloor && t1.declaredUnitPrice !== undefined && (
              <p className="mt-2 text-muted-foreground">
                Price check: ${t1.declaredUnitPrice.toFixed(2)} declared against a $
                {costFloor(t1.costFloor).toFixed(2)} cost floor (ratio{" "}
                {priceRatio(t1.declaredUnitPrice, t1.costFloor).toFixed(2)}) → price
                anomaly {round(priceAnomalyScore(t1.declaredUnitPrice, t1.costFloor))}.
                Place {round(locationRiskScore(t1.location))}, screening{" "}
                {round(entityRiskScore(t1.entityCheck))} (
                {ENTITY_RISK_LABELS[t1.entityCheck ?? "not_checked"]}). Weights{" "}
                {RISK_WEIGHTS.priceAnomaly}/{RISK_WEIGHTS.locationRisk}/
                {RISK_WEIGHTS.entityRisk}.
              </p>
            )}
          </div>

          <div>
            <p className="font-bold">Confidence {scores.confidence}</p>
            <ul className="mt-1 space-y-0.5">
              {scores.confidenceFactors.map((f) => (
                <li key={f.label} className="flex justify-between gap-3">
                  <span className="text-muted-foreground">{f.label}</span>
                  <span
                    className={
                      f.value > 0 ? "font-bold text-verdict-green" : "font-bold text-verdict-red"
                    }
                  >
                    {f.value > 0 ? `+${f.value}` : f.value}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-bold">Transparency {scores.transparency}</p>
            <ul className="mt-1 space-y-0.5">
              {scores.transparencyFactors.map((f) => (
                <li key={f.label} className="flex justify-between gap-3">
                  <span className="text-muted-foreground">{f.label}</span>
                  <span className="font-bold">{f.value}</span>
                </li>
              ))}
            </ul>
            {scores.transparencyCapped && (
              <p className={`mt-1 font-bold ${verdictStyles.red.text}`}>
                Capped at 20 because of the banned-list match.
              </p>
            )}
          </div>

          <Link to="/methodology" className="inline-block font-bold underline">
            See the full method
          </Link>
        </div>
      </Section>

      <Section title="Where this came from">
        <ul className="space-y-1 text-sm text-muted-foreground">
          {brand.sourceFootnotes.map((f) => (
            <li key={f}>· {f}</li>
          ))}
        </ul>
      </Section>

      <ComparePicker slug={slug} />

      <DemoFooter />
    </Shell>
  );
}
