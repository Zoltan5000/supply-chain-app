import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import jsQR from "jsqr";
import { brands, findBrand } from "@/data/brands";
import { Shell } from "@/components/workprint/Shell";
import { QrSticker } from "@/components/workprint/QrSticker";

export const Route = createFileRoute("/scan")({
  head: () => ({
    meta: [
      { title: "Scan a garment label — Vis-a-Vis" },
      {
        name: "description",
        content:
          "Point your camera at the QR sticker on a demo tee, upload a photo of one, or type the brand or RN number instead.",
      },
      { property: "og:title", content: "Scan a garment label — Vis-a-Vis" },
      {
        property: "og:description",
        content: "Scan the QR sticker on a demo tee to see its supply-chain result.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Scan,
});

function Scan() {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [cameraOn, setCameraOn] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [typed, setTyped] = useState("");

  const resolve = useCallback(
    (payload: string) => {
      const match = findBrand(payload);
      if (match) {
        navigate({ to: "/p/$slug", params: { slug: match.slug } });
        return true;
      }
      setMessage(
        `We read "${payload}" but it isn't one of the five demo tees. Pick one below.`,
      );
      return false;
    },
    [navigate],
  );

  const stop = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraOn(false);
  }, []);

  useEffect(() => stop, [stop]);

  const tick = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(data.data, data.width, data.height);
        if (code?.data) {
          stop();
          resolve(code.data.trim());
          return;
        }
      }
    }
    rafRef.current = requestAnimationFrame(tick);
  }, [resolve, stop]);

  const start = async () => {
    setMessage(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      streamRef.current = stream;
      setCameraOn(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      rafRef.current = requestAnimationFrame(tick);
    } catch {
      setCameraOn(false);
      setMessage(
        "No camera here. Upload a photo of the QR sticker, tap a demo tee, or type the code.",
      );
    }
  };

  const onFile = async (file: File) => {
    setMessage(null);
    const bitmap = await createImageBitmap(file);
    const canvas = document.createElement("canvas");
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(bitmap, 0, 0);
    const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(data.data, data.width, data.height);
    if (code?.data) resolve(code.data.trim());
    else setMessage("Couldn't read a QR code in that photo. Try again or type the code.");
  };

  return (
    <Shell>
      <h1 className="text-3xl">Scan the label</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        We read the QR sticker and match it to a brand. The result is brand-level — not a
        claim about the exact shirt in your hand.
      </p>

      <div className="mt-4 overflow-hidden rounded-3xl border-2 border-border bg-card">
        <div className="relative aspect-square w-full bg-muted">
          <video
            ref={videoRef}
            playsInline
            muted
            className={`h-full w-full object-cover ${cameraOn ? "" : "hidden"}`}
          />
          {!cameraOn && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
              <p className="text-sm text-muted-foreground">
                Camera is off. Turn it on to scan a sticker.
              </p>
              <button
                onClick={start}
                className="rounded-2xl bg-cobalt px-5 py-3 text-sm font-black text-cobalt-foreground"
              >
                Turn on camera
              </button>
            </div>
          )}
          <canvas ref={canvasRef} className="hidden" />
        </div>
        {cameraOn && (
          <button onClick={stop} className="w-full px-4 py-3 text-sm font-bold">
            Stop camera
          </button>
        )}
      </div>

      {message && (
        <p className="mt-3 rounded-2xl bg-verdict-amber-soft p-3 text-sm">{message}</p>
      )}

      <div className="mt-4 grid gap-3">
        <label className="rounded-3xl border-2 border-dashed border-border p-4 text-center text-sm font-bold">
          Upload a photo of a QR code
          <input
            type="file"
            accept="image/*"
            className="mt-2 block w-full text-xs font-normal"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onFile(f);
            }}
          />
        </label>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            resolve(typed);
          }}
          className="rounded-3xl border-2 border-border bg-card p-4"
        >
          <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
            Type the code, brand or RN
          </label>
          <input
            value={typed}
            onChange={(e) => setTyped(e.target.value)}
            maxLength={80}
            placeholder="WP-TEE-03"
            className="mt-2 w-full rounded-2xl border-2 border-border bg-background px-4 py-3 outline-none focus:border-cobalt"
          />
          <button className="mt-3 w-full rounded-2xl bg-foreground px-4 py-3 text-sm font-black text-background">
            Look it up
          </button>
        </form>
      </div>

      <h2 className="mt-6 text-xl">Demo stickers</h2>
      <div className="mt-3 grid grid-cols-3 gap-3">
        {brands.map((b) => (
          <Link
            key={b.slug}
            to="/p/$slug"
            params={{ slug: b.slug }}
            className="flex flex-col items-center gap-1 rounded-2xl bg-muted/60 p-2 text-center"
          >
            <QrSticker payload={b.qrPayload} size={64} />
            <span className="text-[11px] font-bold leading-tight">{b.brand}</span>
          </Link>
        ))}
      </div>
    </Shell>
  );
}
