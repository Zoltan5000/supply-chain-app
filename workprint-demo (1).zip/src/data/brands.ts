import {
  computeScores,
  type ConfidenceInputs,
  type ScoreBreakdown,
  type SourceType,
  type TierNode,
  type TransparencyInputs,
  type Verdict,
  type WageInputs,
} from "@/config/scoring";

import teeVerdant from "@/assets/tee-verdant.jpg";
import teeBloomhaus from "@/assets/tee-bloomhaus.jpg";
import teeNorthloop from "@/assets/tee-northloop.jpg";
import teeStatepoint from "@/assets/tee-statepoint.jpg";
import teeEveryday from "@/assets/tee-everyday.jpg";

export interface Evidence {
  id: string;
  title: string;
  body: string;
  sourceName: string;
  sourceType: SourceType;
  date: string;
  independent: boolean;
  kind: "finding" | "context";
  humanVerified: boolean;
}

export interface Gap {
  id: string;
  label: string;
  whyItMatters: string;
  severity: "high" | "medium" | "low";
}

export interface Supplier {
  name: string;
  country: string;
  tier: 1 | 2 | 3 | 4;
  screenStatus: string;
  badges: string[];
}

export interface Brand {
  slug: string;
  qrPayload: string;
  brand: string;
  productName: string;
  rn: string;
  countryOfOrigin: string;
  fiber: string;
  image: string;
  accent: "coral" | "sunflower" | "lime" | "cobalt";
  retailPrice: number;
  declaredUnitPrice: number;
  blurb: string;
  targetVerdict: Verdict;
  flags: { uflpaEntityMatch: boolean; cbpWroActive: boolean };
  tiers: TierNode[];
  suppliers: Supplier[];
  evidence: Evidence[];
  gaps: Gap[];
  confidenceInputs: ConfidenceInputs;
  transparencyInputs: TransparencyInputs;
  wage: WageInputs;
  sourceFootnotes: string[];
}

const conf = (o: Partial<ConfidenceInputs>): ConfidenceInputs => ({
  recentIndependentAuditOfFinalAssembly: false,
  finalAssemblyFacilityNamed: false,
  multipleIndependentSourceTypes: false,
  tier2Named: false,
  numericWageOrPriceData: false,
  evidenceYoungerThan12Months: false,
  fairPayDimensionMissing: false,
  onlyBrandOwnedSources: false,
  keySupplierIsTradingCompany: false,
  tier3Or4Unknown: false,
  ...o,
});

export const brands: Brand[] = [
  /* ---------------------------------------------------------------- 1 */
  {
    slug: "verdant-cotton-co",
    qrPayload: "WP-TEE-01",
    brand: "Verdant Cotton Co.",
    productName: "Everyday Crew Tee",
    rn: "RN 148820",
    countryOfOrigin: "Portugal",
    fiber: "100% cotton",
    image: teeVerdant,
    accent: "lime",
    retailPrice: 38,
    declaredUnitPrice: 8.9,
    blurb: "Names its sewing factory and its mill, and publishes the audit.",
    targetVerdict: "green",
    flags: { uflpaEntityMatch: false, cbpWroActive: false },
    tiers: [
      {
        tier: 0,
        stage: "Brand / finished tee",
        actor: "Verdant Cotton Co.",
        country: "Portugal",
        status: "known",
        declaredUnitPrice: 8.9,
        costFloor: {
          materials: 3.2,
          laborHours: 0.55,
          minWagePerHour: 5.1,
          overhead: 1.1,
          shipping: 0.6,
        },
        location: { dolList: false, prevalence: "low" },
        entityCheck: "checked_clear",
        sourceFootnote: "Company supplier list + independent audit summary",
      },
      {
        tier: 1,
        stage: "Cut-and-sew garment factory",
        actor: "Atlântico Confecções, Barcelos",
        country: "Portugal",
        status: "known",
        declaredUnitPrice: 8.9,
        costFloor: {
          materials: 3.2,
          laborHours: 0.55,
          minWagePerHour: 5.1,
          overhead: 1.1,
          shipping: 0.6,
        },
        location: { dolList: false, prevalence: "low" },
        entityCheck: "checked_clear",
        badges: ["Named address", "Audited 2026"],
        sourceFootnote: "Independent audit body report, supplier registry listing",
      },
      {
        tier: 2,
        stage: "Fabric mill, dye, finish, trims",
        actor: "Riomar Têxtil",
        country: "Portugal",
        status: "known",
        location: { dolList: false, prevalence: "low" },
        entityCheck: "checked_clear",
        badges: ["Named mill"],
        sourceFootnote: "Company disclosure + certification registry",
      },
      {
        tier: 3,
        stage: "Yarn spinning",
        actor: "Kavaklı Iplik",
        country: "Türkiye",
        status: "known",
        location: { dolList: false, prevalence: "medium" },
        entityCheck: "checked_clear",
        sourceFootnote: "Certification chain-of-custody record",
      },
      {
        tier: 4,
        stage: "Raw cotton: ginning and farms",
        actor: "Aegean grower cooperative (region level)",
        country: "Türkiye / Greece",
        status: "estimated",
        location: { dolList: false, prevalence: "low" },
        entityCheck: "partly_checked",
        countryMix: [
          { country: "Türkiye", share: 0.6, risk: 35 },
          { country: "Greece", share: 0.4, risk: 15 },
        ],
        sourceFootnote: "Certification scope + regional sourcing declaration",
      },
    ],
    suppliers: [
      {
        name: "Atlântico Confecções",
        country: "Portugal",
        tier: 1,
        screenStatus: "Screened, no matches",
        badges: ["Named address", "Independent audit 2026"],
      },
      {
        name: "Riomar Têxtil",
        country: "Portugal",
        tier: 2,
        screenStatus: "Screened, no matches",
        badges: ["Named mill"],
      },
      {
        name: "Kavaklı Iplik",
        country: "Türkiye",
        tier: 3,
        screenStatus: "Screened, no matches",
        badges: ["Chain-of-custody certificate"],
      },
    ],
    evidence: [
      {
        id: "v1",
        title: "Independent audit of the sewing factory",
        body: "An outside auditor visited the named factory, interviewed workers off site and found no indicators of forced labor. Wage records matched payslips.",
        sourceName: "Independent audit body",
        sourceType: "independent_audit",
        date: "2026-03-14",
        independent: true,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "v2",
        title: "Unit price sits above our cost floor",
        body: "The declared price per shirt is above what it would cost to make it legally at minimum wage in Portugal, so the price itself is not a red flag.",
        sourceName: "Customs value + cost-floor model",
        sourceType: "customs_shipment",
        date: "2026-01-22",
        independent: true,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "v3",
        title: "Cotton region context",
        body: "Cotton from this Mediterranean region is generally lower risk than cotton from the highest-risk growing areas, but farm-level labor is rarely checked anywhere.",
        sourceName: "Public country risk research",
        sourceType: "news",
        date: "2025-11-02",
        independent: true,
        kind: "context",
        humanVerified: false,
      },
    ],
    gaps: [
      {
        id: "g1",
        label: "Farm level still estimated",
        whyItMatters: "Cotton farms are where forced labor is hardest to see, even in low-risk regions.",
        severity: "medium",
      },
    ],
    confidenceInputs: conf({
      recentIndependentAuditOfFinalAssembly: true,
      finalAssemblyFacilityNamed: true,
      multipleIndependentSourceTypes: true,
      tier2Named: true,
      numericWageOrPriceData: true,
      evidenceYoungerThan12Months: true,
    }),
    transparencyInputs: {
      traceability: { raw: 88, sourceConfidence: "verified" },
      laborHumanRights: { raw: 82, sourceConfidence: "verified" },
      wageTransparency: { raw: 70, sourceConfidence: "verified" },
      environment: { raw: 65, sourceConfidence: "ngo_union" },
      legalCompliance: { raw: 85, sourceConfidence: "verified" },
      companyDisclosure: { raw: 90, sourceConfidence: "verified" },
    },
    wage: { estimatedWagePerHour: 5.4, livingWagePerHour: 6.2, laborMinutes: 33 },
    sourceFootnotes: [
      "Independent audit report (third-party auditor)",
      "Company supplier disclosure",
      "Certification chain-of-custody registry",
      "Customs shipment value record",
    ],
  },

  /* ---------------------------------------------------------------- 2 */
  {
    slug: "bloomhaus",
    qrPayload: "WP-TEE-02",
    brand: "Bloomhaus",
    productName: "Soft Bloom Tee",
    rn: "RN 159034",
    countryOfOrigin: "Bangladesh",
    fiber: "100% cotton",
    image: teeBloomhaus,
    accent: "coral",
    retailPrice: 29,
    declaredUnitPrice: 4.4,
    blurb: "Lots of friendly promises, almost nothing you can check.",
    targetVerdict: "grey",
    flags: { uflpaEntityMatch: false, cbpWroActive: false },
    tiers: [
      {
        tier: 0,
        stage: "Brand / finished tee",
        actor: "Bloomhaus",
        country: "United States",
        status: "known",
        location: { dolList: false, prevalence: "low" },
        entityCheck: "partly_checked",
        sourceFootnote: "Brand website claims only",
      },
      {
        tier: 1,
        stage: "Cut-and-sew garment factory",
        actor: null,
        country: "Bangladesh",
        status: "estimated",
        location: { dolList: false, prevalence: "medium" },
        entityCheck: "not_checked",
        sourceFootnote: "Country of origin on the care label; no factory named",
      },
      {
        tier: 2,
        stage: "Fabric mill, dye, finish, trims",
        actor: null,
        country: null,
        status: "unknown",
        countryMix: [
          { country: "China", share: 0.35, risk: 85 },
          { country: "India", share: 0.3, risk: 45 },
          { country: "Bangladesh", share: 0.2, risk: 40 },
          { country: "Other", share: 0.15, risk: 30 },
        ],
        sourceFootnote: "Trade-lane import mix (country level, not this company)",
      },
      {
        tier: 3,
        stage: "Yarn spinning",
        actor: null,
        country: null,
        status: "unknown",
        countryMix: [
          { country: "China", share: 0.4, risk: 85 },
          { country: "India", share: 0.35, risk: 45 },
          { country: "Other", share: 0.25, risk: 30 },
        ],
        sourceFootnote: "Trade-lane import mix (country level, not this company)",
      },
      {
        tier: 4,
        stage: "Raw cotton: ginning and farms",
        actor: null,
        country: null,
        status: "unknown",
        countryMix: [
          { country: "China", share: 0.3, risk: 90 },
          { country: "India", share: 0.3, risk: 50 },
          { country: "Brazil", share: 0.25, risk: 25 },
          { country: "United States", share: 0.15, risk: 10 },
        ],
        sourceFootnote: "Cotton import mix for the lane (country level)",
      },
    ],
    suppliers: [],
    evidence: [
      {
        id: "b1",
        title: "Brand says it uses “ethical partners”",
        body: "The website says the company works with ethical partners and cares about people. There is no factory name, no audit, no numbers behind it.",
        sourceName: "Bloomhaus website",
        sourceType: "brand_claim",
        date: "2026-02-08",
        independent: false,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "b2",
        title: "What usually sits behind an unnamed fabric supplier",
        body: "On this trade lane, a large share of fabric and yarn comes from countries that appear on official forced-labor goods lists. This is a general pattern, not a claim about any Bloomhaus supplier.",
        sourceName: "Public import statistics",
        sourceType: "trade_record",
        date: "2025-12-01",
        independent: true,
        kind: "context",
        humanVerified: false,
      },
    ],
    gaps: [
      {
        id: "g1",
        label: "No factory named",
        whyItMatters: "Without a named factory nobody can check anything on the ground.",
        severity: "high",
      },
      {
        id: "g2",
        label: "Fabric mill unknown",
        whyItMatters: "Dyeing and finishing is where a lot of hidden subcontracting happens.",
        severity: "high",
      },
      {
        id: "g3",
        label: "Yarn and cotton unknown",
        whyItMatters: "This is the part of the chain with the highest forced-labor risk.",
        severity: "high",
      },
      {
        id: "g4",
        label: "No wage numbers",
        whyItMatters: "Pay claims without numbers can't be compared to a living wage.",
        severity: "medium",
      },
    ],
    confidenceInputs: conf({
      evidenceYoungerThan12Months: true,
      fairPayDimensionMissing: true,
      onlyBrandOwnedSources: true,
      tier3Or4Unknown: true,
    }),
    transparencyInputs: {
      traceability: { raw: 20, sourceConfidence: "proxy" },
      laborHumanRights: { raw: 40, sourceConfidence: "proxy" },
      wageTransparency: { raw: 10, sourceConfidence: "unknown" },
      environment: { raw: 45, sourceConfidence: "proxy" },
      legalCompliance: { raw: 35, sourceConfidence: "proxy" },
      companyDisclosure: { raw: 30, sourceConfidence: "proxy" },
    },
    wage: { estimatedWagePerHour: 0.9, livingWagePerHour: 2.4, laborMinutes: 30 },
    sourceFootnotes: [
      "Brand-owned marketing pages",
      "Public import statistics (country level)",
    ],
  },

  /* ---------------------------------------------------------------- 3 */
  {
    slug: "northloop-basics",
    qrPayload: "WP-TEE-03",
    brand: "Northloop Basics",
    productName: "Heavyweight Box Tee",
    rn: "RN 132477",
    countryOfOrigin: "Vietnam",
    fiber: "100% cotton",
    image: teeNorthloop,
    accent: "cobalt",
    retailPrice: 32,
    declaredUnitPrice: 6.1,
    blurb: "Sewing factory is named. Everything behind the fabric gets murky.",
    targetVerdict: "amber",
    flags: { uflpaEntityMatch: false, cbpWroActive: false },
    tiers: [
      {
        tier: 0,
        stage: "Brand / finished tee",
        actor: "Northloop Basics",
        country: "United States",
        status: "known",
        location: { dolList: false, prevalence: "low" },
        entityCheck: "checked_clear",
        sourceFootnote: "Company disclosure + screening run",
      },
      {
        tier: 1,
        stage: "Cut-and-sew garment factory",
        actor: "Songlam Garment JSC, Bình Dương",
        country: "Vietnam",
        status: "known",
        declaredUnitPrice: 6.1,
        costFloor: {
          materials: 2.4,
          laborHours: 0.45,
          minWagePerHour: 1.05,
          overhead: 0.8,
          shipping: 0.45,
        },
        location: { dolList: false, prevalence: "medium" },
        entityCheck: "checked_clear",
        badges: ["Named address", "Audited 2025"],
        sourceFootnote: "Supplier registry listing + audit summary",
      },
      {
        tier: 2,
        stage: "Fabric mill, dye, finish, trims",
        actor: "Nine named fabric and trim suppliers (mostly CN / HK)",
        country: "China / Hong Kong",
        status: "known",
        location: { dolList: true, prevalence: "high" },
        entityCheck: "partly_checked",
        badges: ["9 suppliers listed", "Partly screened"],
        sourceFootnote: "Customs shipment records + company list",
      },
      {
        tier: 3,
        stage: "Yarn spinning",
        actor: null,
        country: null,
        status: "unknown",
        countryMix: [
          { country: "China", share: 0.45, risk: 85 },
          { country: "Vietnam", share: 0.25, risk: 40 },
          { country: "India", share: 0.2, risk: 45 },
          { country: "Other", share: 0.1, risk: 30 },
        ],
        sourceFootnote: "Trade-lane yarn import mix (country level)",
      },
      {
        tier: 4,
        stage: "Raw cotton: ginning and farms",
        actor: null,
        country: null,
        status: "unknown",
        countryMix: [
          { country: "China", share: 0.35, risk: 90 },
          { country: "Brazil", share: 0.25, risk: 25 },
          { country: "India", share: 0.2, risk: 50 },
          { country: "United States", share: 0.2, risk: 10 },
        ],
        sourceFootnote: "Cotton import mix for the lane (country level)",
      },
    ],
    suppliers: [
      {
        name: "Songlam Garment JSC",
        country: "Vietnam",
        tier: 1,
        screenStatus: "Screened, no matches",
        badges: ["Named address", "Independent audit 2025"],
      },
      {
        name: "Yuehai Textile Trading",
        country: "Hong Kong",
        tier: 2,
        screenStatus: "Partly screened",
        badges: ["Trading company", "No factory named"],
      },
      {
        name: "Huaxing Dye & Finish",
        country: "China",
        tier: 2,
        screenStatus: "Partly screened",
        badges: ["Named mill"],
      },
    ],
    evidence: [
      {
        id: "n1",
        title: "Sewing factory named and audited",
        body: "The Vietnamese cut-and-sew plant is named with an address and was audited last year. No forced-labor indicators were recorded there.",
        sourceName: "Independent audit body",
        sourceType: "independent_audit",
        date: "2025-10-30",
        independent: true,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "n2",
        title: "Fabric comes mostly through one trading company",
        body: "Shipment records show most fabric arriving via a Hong Kong trading company. Trading companies sit between the brand and the actual mill, so the mill identity is not confirmed.",
        sourceName: "Customs shipment records",
        sourceType: "customs_shipment",
        date: "2026-01-19",
        independent: true,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "n3",
        title: "This trade lane leans on listed cotton countries",
        body: "Many fabric exporters on this lane sit in countries on the official forced-labor goods list for cotton. That is a pattern for the lane, not a finding about any named mill here.",
        sourceName: "Official goods list + import statistics",
        sourceType: "official_list",
        date: "2025-09-15",
        independent: true,
        kind: "context",
        humanVerified: false,
      },
      {
        id: "n4",
        title: "Unverified lead — not shown to shoppers",
        body: "An unconfirmed forum post naming a subcontractor. Not verified by a human reviewer, so it is excluded from the shopper view.",
        sourceName: "Open web",
        sourceType: "news",
        date: "2026-02-11",
        independent: false,
        kind: "finding",
        humanVerified: false,
      },
      {
        id: "n5",
        title: "Unverified lead — not shown to shoppers",
        body: "A second-hand claim about overtime at an unnamed site. Not verified, so it is excluded.",
        sourceName: "Open web",
        sourceType: "news",
        date: "2026-03-01",
        independent: false,
        kind: "finding",
        humanVerified: false,
      },
    ],
    gaps: [
      {
        id: "g1",
        label: "Mill hidden behind a trader",
        whyItMatters: "A trading company can swap the real factory without telling the brand.",
        severity: "high",
      },
      {
        id: "g2",
        label: "Yarn spinning unknown",
        whyItMatters: "Spinning is a common entry point for high-risk cotton.",
        severity: "high",
      },
      {
        id: "g3",
        label: "Raw cotton unknown",
        whyItMatters: "Nobody has traced this shirt back to a farm region.",
        severity: "high",
      },
    ],
    confidenceInputs: conf({
      recentIndependentAuditOfFinalAssembly: true,
      finalAssemblyFacilityNamed: true,
      multipleIndependentSourceTypes: true,
      tier2Named: true,
      evidenceYoungerThan12Months: true,
      keySupplierIsTradingCompany: true,
      tier3Or4Unknown: true,
    }),
    transparencyInputs: {
      traceability: { raw: 60, sourceConfidence: "verified" },
      laborHumanRights: { raw: 55, sourceConfidence: "ngo_union" },
      wageTransparency: { raw: 35, sourceConfidence: "proxy" },
      environment: { raw: 50, sourceConfidence: "industry_context" },
      legalCompliance: { raw: 55, sourceConfidence: "verified" },
      companyDisclosure: { raw: 65, sourceConfidence: "verified" },
    },
    wage: { estimatedWagePerHour: 1.15, livingWagePerHour: 2.1, laborMinutes: 27 },
    sourceFootnotes: [
      "Independent audit report",
      "Customs shipment records",
      "Official forced-labor goods list (context)",
      "Company supplier disclosure",
    ],
  },

  /* ---------------------------------------------------------------- 4 */
  {
    slug: "statepoint-apparel",
    qrPayload: "WP-TEE-04",
    brand: "Statepoint Apparel",
    productName: "Classic Pocket Tee",
    rn: "RN 171905",
    countryOfOrigin: "China",
    fiber: "100% cotton",
    image: teeStatepoint,
    accent: "coral",
    retailPrice: 24,
    declaredUnitPrice: 3.8,
    blurb: "One supplier matches an official banned-entity list.",
    targetVerdict: "red",
    flags: { uflpaEntityMatch: true, cbpWroActive: false },
    tiers: [
      {
        tier: 0,
        stage: "Brand / finished tee",
        actor: "Statepoint Apparel",
        country: "United States",
        status: "known",
        location: { dolList: false, prevalence: "low" },
        entityCheck: "partly_checked",
        sourceFootnote: "Company disclosure",
      },
      {
        tier: 1,
        stage: "Cut-and-sew garment factory",
        actor: "Jianfeng Apparel Works",
        country: "China",
        status: "known",
        declaredUnitPrice: 3.8,
        costFloor: {
          materials: 1.9,
          laborHours: 0.45,
          minWagePerHour: 1.9,
          overhead: 0.7,
          shipping: 0.4,
        },
        location: { dolList: true, prevalence: "high" },
        entityCheck: "partly_checked",
        badges: ["Named factory"],
        sourceFootnote: "Customs records + company list",
      },
      {
        tier: 2,
        stage: "Fabric mill, dye, finish, trims",
        actor: "Tianyuan Cotton Textile Group",
        country: "China",
        status: "known",
        location: { dolList: true, prevalence: "high" },
        entityCheck: "watchlist_hit",
        badges: ["Banned-list match", "Human verified"],
        sourceFootnote: "Official entity list entry (human verified)",
      },
      {
        tier: 3,
        stage: "Yarn spinning",
        actor: "Affiliate of the listed group",
        country: "China",
        status: "estimated",
        location: { dolList: true, prevalence: "high" },
        entityCheck: "watchlist_hit",
        sourceFootnote: "Corporate ownership record (group affiliate)",
      },
      {
        tier: 4,
        stage: "Raw cotton: ginning and farms",
        actor: null,
        country: null,
        status: "unknown",
        countryMix: [
          { country: "China (listed region)", share: 0.7, risk: 95 },
          { country: "Other", share: 0.3, risk: 40 },
        ],
        sourceFootnote: "Group sourcing footprint (country level)",
      },
    ],
    suppliers: [
      {
        name: "Jianfeng Apparel Works",
        country: "China",
        tier: 1,
        screenStatus: "Partly screened",
        badges: ["Named factory"],
      },
      {
        name: "Tianyuan Cotton Textile Group",
        country: "China",
        tier: 2,
        screenStatus: "Banned-list match",
        badges: ["Official entity list", "Human verified"],
      },
    ],
    evidence: [
      {
        id: "s1",
        title: "Fabric supplier matched an official banned-entity list",
        body: "A human reviewer confirmed that the named fabric supplier matches an entry on the official forced-labor entity list, dated 12 January 2026. Goods linked to listed entities can be stopped at the US border.",
        sourceName: "Official entity list",
        sourceType: "official_list",
        date: "2026-01-12",
        independent: true,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "s2",
        title: "Yarn supplier is owned by the same group",
        body: "Ownership records tie the spinning mill to the same corporate group as the listed fabric supplier.",
        sourceName: "Corporate ownership registry",
        sourceType: "trade_record",
        date: "2026-01-20",
        independent: true,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "s3",
        title: "What a list match means at the border",
        body: "Listing means imports are presumed to involve forced labor unless the importer proves otherwise. It is an official status, not a court verdict.",
        sourceName: "Public enforcement guidance",
        sourceType: "official_list",
        date: "2025-08-04",
        independent: true,
        kind: "context",
        humanVerified: false,
      },
    ],
    gaps: [
      {
        id: "g1",
        label: "No response from the brand",
        whyItMatters: "The company has not published a reply or a remediation plan.",
        severity: "high",
      },
      {
        id: "g2",
        label: "Cotton origin unknown",
        whyItMatters: "The group's cotton footprint sits largely in the listed region.",
        severity: "high",
      },
    ],
    confidenceInputs: conf({
      finalAssemblyFacilityNamed: true,
      multipleIndependentSourceTypes: true,
      tier2Named: true,
      numericWageOrPriceData: true,
      evidenceYoungerThan12Months: true,
      tier3Or4Unknown: true,
    }),
    transparencyInputs: {
      traceability: { raw: 55, sourceConfidence: "verified" },
      laborHumanRights: { raw: 25, sourceConfidence: "proxy" },
      wageTransparency: { raw: 20, sourceConfidence: "proxy" },
      environment: { raw: 40, sourceConfidence: "industry_context" },
      legalCompliance: { raw: 15, sourceConfidence: "verified" },
      companyDisclosure: { raw: 45, sourceConfidence: "verified" },
    },
    wage: { estimatedWagePerHour: 1.6, livingWagePerHour: 3.4, laborMinutes: 27 },
    sourceFootnotes: [
      "Official forced-labor entity list (human verified)",
      "Corporate ownership registry",
      "Customs shipment records",
    ],
  },

  /* ---------------------------------------------------------------- 5 */
  {
    slug: "everyday-3-pack",
    qrPayload: "WP-TEE-05",
    brand: "Everyday Value",
    productName: "3-Pack Cotton Tee",
    rn: "RN 186312",
    countryOfOrigin: "Pakistan",
    fiber: "100% cotton",
    image: teeEveryday,
    accent: "sunflower",
    retailPrice: 12,
    declaredUnitPrice: 2.4,
    blurb: "The price is below what it should cost to make this legally.",
    targetVerdict: "red",
    flags: { uflpaEntityMatch: false, cbpWroActive: false },
    tiers: [
      {
        tier: 0,
        stage: "Brand / finished tee",
        actor: "Everyday Value",
        country: "United States",
        status: "known",
        declaredUnitPrice: 2.4,
        costFloor: {
          materials: 1.6,
          laborHours: 0.5,
          minWagePerHour: 1.2,
          overhead: 0.5,
          shipping: 0.35,
        },
        location: { dolList: false, prevalence: "low" },
        entityCheck: "partly_checked",
        sourceFootnote: "Retail listing + customs value",
      },
      {
        tier: 1,
        stage: "Cut-and-sew garment factory",
        actor: "Ravi Stitchworks, Faisalabad",
        country: "Pakistan",
        status: "known",
        declaredUnitPrice: 2.4,
        costFloor: {
          materials: 1.6,
          laborHours: 0.5,
          minWagePerHour: 1.2,
          overhead: 0.5,
          shipping: 0.35,
        },
        location: { dolList: true, prevalence: "high" },
        entityCheck: "not_checked",
        badges: ["Named factory", "Price below cost floor"],
        sourceFootnote: "Customs shipment records",
      },
      {
        tier: 2,
        stage: "Fabric mill, dye, finish, trims",
        actor: "Chenab Mills (partial disclosure)",
        country: "Pakistan",
        status: "estimated",
        location: { dolList: true, prevalence: "high" },
        entityCheck: "not_checked",
        sourceFootnote: "Partial shipment match, not confirmed by the company",
      },
      {
        tier: 3,
        stage: "Yarn spinning",
        actor: null,
        country: null,
        status: "unknown",
        countryMix: [
          { country: "Pakistan", share: 0.5, risk: 65 },
          { country: "China", share: 0.3, risk: 85 },
          { country: "Other", share: 0.2, risk: 40 },
        ],
        sourceFootnote: "Trade-lane yarn import mix (country level)",
      },
      {
        tier: 4,
        stage: "Raw cotton: ginning and farms",
        actor: null,
        country: null,
        status: "unknown",
        countryMix: [
          { country: "Pakistan", share: 0.45, risk: 80 },
          { country: "Uzbekistan", share: 0.2, risk: 85 },
          { country: "China", share: 0.2, risk: 90 },
          { country: "Other", share: 0.15, risk: 40 },
        ],
        sourceFootnote: "Cotton import mix for the lane (country level)",
      },
    ],
    suppliers: [
      {
        name: "Ravi Stitchworks",
        country: "Pakistan",
        tier: 1,
        screenStatus: "Not screened",
        badges: ["Named factory"],
      },
      {
        name: "Chenab Mills",
        country: "Pakistan",
        tier: 2,
        screenStatus: "Not screened",
        badges: ["Partial match only"],
      },
    ],
    evidence: [
      {
        id: "e1",
        title: "The price doesn't add up",
        body: "At the declared price per shirt, there is not enough money in the shirt to cover materials, legal minimum wage, overhead and shipping. Something in the chain is being squeezed.",
        sourceName: "Customs value + cost-floor model",
        sourceType: "customs_shipment",
        date: "2026-02-27",
        independent: true,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "e2",
        title: "Sewing factory named, never screened",
        body: "Shipment records name the sewing factory, but nobody has run it against sanctions or forced-labor lists.",
        sourceName: "Customs shipment records",
        sourceType: "customs_shipment",
        date: "2026-02-27",
        independent: true,
        kind: "finding",
        humanVerified: true,
      },
      {
        id: "e3",
        title: "Cotton on this lane sits on official lists",
        body: "Cotton from several of the countries feeding this lane appears on official forced- and child-labor goods lists. This describes the lane, not a named farm or gin.",
        sourceName: "Official goods list",
        sourceType: "official_list",
        date: "2025-09-30",
        independent: true,
        kind: "context",
        humanVerified: false,
      },
    ],
    gaps: [
      {
        id: "g1",
        label: "No screening at all",
        whyItMatters: "No supplier here has been checked against official lists.",
        severity: "high",
      },
      {
        id: "g2",
        label: "Cotton origin unknown",
        whyItMatters: "The likely growing countries include some of the highest-risk ones.",
        severity: "high",
      },
      {
        id: "g3",
        label: "No wage evidence",
        whyItMatters: "The price gap suggests pressure on wages, but nobody has measured it.",
        severity: "medium",
      },
    ],
    confidenceInputs: conf({
      finalAssemblyFacilityNamed: true,
      multipleIndependentSourceTypes: true,
      tier2Named: true,
      numericWageOrPriceData: true,
      evidenceYoungerThan12Months: true,
      tier3Or4Unknown: true,
    }),
    transparencyInputs: {
      traceability: { raw: 40, sourceConfidence: "industry_context" },
      laborHumanRights: { raw: 20, sourceConfidence: "proxy" },
      wageTransparency: { raw: 15, sourceConfidence: "proxy" },
      environment: { raw: 30, sourceConfidence: "proxy" },
      legalCompliance: { raw: 30, sourceConfidence: "industry_context" },
      companyDisclosure: { raw: 25, sourceConfidence: "proxy" },
    },
    wage: { estimatedWagePerHour: 0.75, livingWagePerHour: 2.0, laborMinutes: 30 },
    sourceFootnotes: [
      "Customs shipment records",
      "Cost-floor model (minimum wage benchmark)",
      "Official forced-labor goods list (context)",
    ],
  },
];

/** Scores are recomputed from the seed with the published formulas. */
export function scoresFor(brand: Brand): ScoreBreakdown {
  return computeScores({
    tiers: brand.tiers,
    confidenceInputs: brand.confidenceInputs,
    transparencyInputs: brand.transparencyInputs,
    flags: brand.flags,
  });
}

export const shopperEvidence = (brand: Brand) =>
  brand.evidence.filter((e) => e.kind === "context" || e.humanVerified);

export function findBrand(query: string): Brand | undefined {
  const q = query.trim().toLowerCase().replace(/\s+/g, " ");
  if (!q) return undefined;
  return brands.find(
    (b) =>
      b.slug === q ||
      b.qrPayload.toLowerCase() === q ||
      b.brand.toLowerCase() === q ||
      b.brand.toLowerCase().includes(q) ||
      b.rn.toLowerCase() === q ||
      b.rn.toLowerCase().replace("rn ", "") === q.replace("rn ", ""),
  );
}

export const getBrand = (slug: string) => brands.find((b) => b.slug === slug);
