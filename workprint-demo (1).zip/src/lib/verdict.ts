import type { Verdict } from "@/config/scoring";

export const verdictStyles: Record<
  Verdict,
  { chip: string; soft: string; text: string; bar: string; dot: string; label: string }
> = {
  green: {
    chip: "bg-verdict-green text-primary-foreground",
    soft: "bg-verdict-green-soft",
    text: "text-verdict-green",
    bar: "bg-verdict-green",
    dot: "bg-verdict-green",
    label: "Green",
  },
  amber: {
    chip: "bg-verdict-amber text-sunflower-foreground",
    soft: "bg-verdict-amber-soft",
    text: "text-verdict-amber",
    bar: "bg-verdict-amber",
    dot: "bg-verdict-amber",
    label: "Amber",
  },
  red: {
    chip: "bg-verdict-red text-primary-foreground",
    soft: "bg-verdict-red-soft",
    text: "text-verdict-red",
    bar: "bg-verdict-red",
    dot: "bg-verdict-red",
    label: "Red",
  },
  grey: {
    chip: "bg-verdict-grey text-primary-foreground",
    soft: "bg-verdict-grey-soft",
    text: "text-verdict-grey",
    bar: "bg-verdict-grey",
    dot: "bg-verdict-grey",
    label: "Grey",
  },
};

export const accentStyles: Record<string, string> = {
  coral: "bg-coral/15",
  sunflower: "bg-sunflower/25",
  lime: "bg-lime/20",
  cobalt: "bg-cobalt/15",
};
